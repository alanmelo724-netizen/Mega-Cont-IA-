# Mega Cont IA — base integrada

Esta carpeta integra el código fuente de ContaIA Global con los catálogos PUC y el gestor de cuentas personalizadas del paquete Mega Cont IA.

## Qué se incorporó

- Catálogos JSON suministrados: comercial, educación superior y financiero.
- Pantalla **Plan de cuentas** con búsqueda, creación de cuentas auxiliares/subauxiliares e importación/plantilla Excel.
- Estado de catálogos personalizados por empresa, integrado al estado de la aplicación.
- Pantalla **Base de datos y respaldos** con autenticación Supabase, sincronización manual/automática y descarga de un ZIP de respaldo.
- Migración RLS `supabase/migrations/001_user_app_state.sql`.
- Variables de entorno de ejemplo en `.env.example`.

## Configurar Supabase

1. Crea un proyecto Supabase propio.
2. En el SQL Editor del proyecto, ejecuta `supabase/migrations/001_user_app_state.sql`.
3. Copia `.env.example` a `.env.local`.
4. Configura `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` con los valores de **Project Settings → API**. Nunca pongas `service_role` en el frontend.
5. Instala dependencias y ejecuta `npm run dev`.
6. En la aplicación abre **Base de datos y respaldos**, crea/inicia sesión y ejecuta **Sincronizar y verificar**.

## Instalar y ejecutar

```bash
npm install
npm run validate:puc
npm run dev
npm run build
npm test
```

## Estado y límites conocidos

- La integración de Supabase está implementada en código, pero no se puede declarar conectada hasta configurar las credenciales de un proyecto real y ejecutar la prueba de sincronización.
- La persistencia en nube de esta versión usa un documento JSON por usuario autenticado, protegido por RLS. Es una primera etapa de conexión; antes de producción, el modelo debe normalizarse en tablas contables, empresas y membresías, con controles de acceso por empresa.
- El ZIP descargable contiene una exportación JSON del estado local y, si hay sesión, el estado disponible en la nube. No sustituye el backup administrado de PostgreSQL y la restauración aún debe probarse en un entorno aislado.
- Los catálogos tienen validación estructural, pero el cotejo línea por línea con los PDF y la verificación de vigencia normativa siguen pendientes.
- No se ha realizado habilitación DIAN ni se afirma que exista facturación electrónica habilitada.
- No usar datos reales sensibles ni producción hasta completar las pruebas, seguridad, restauración y revisión contable/legal.
