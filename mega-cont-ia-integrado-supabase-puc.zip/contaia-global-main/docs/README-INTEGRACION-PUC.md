# Mega Cont IA — actualización de catálogos PUC y gestor de cuentas

## Contenido
- `src/data/puc/comercial.json`: extracción del PDF `PUC_copia.pdf` (PUC comerciantes, Decreto 2650 de 1993).
- `src/data/puc/educacion-superior.json`: extracción del PDF de Instituciones de Educación Superior, actualizado con Resolución 081 de 2026.
- `src/data/puc/financiero.json`: extracción del Catálogo Único de Información Financiera con Fines de Supervisión de la Superintendencia Financiera.
- `src/lib/pucCatalog.ts`: tipos, validación y creación de cuentas personalizadas.
- `src/components/accounts/PucAccountManager.tsx`: interfaz React para crear cuentas y cargar Excel.
- `supabase/migrations/002_custom_puc_accounts.sql`: tabla aislada por empresa con RLS.
- `scripts/validate-puc-json.mjs`: verificador de sintaxis, códigos numéricos, longitud y duplicados.
- `docs/REPORTE_VERIFICACION_JSON.json`: recuento y hash SHA-256 de cada PDF fuente.

## Recuento extraído
- Comercial: 2.516 códigos únicos.
- Educación superior 2026: 3.888 códigos únicos, incluidos códigos de ocho dígitos de desagregación.
- Financiero: 3.842 códigos únicos.

Los recuentos son de las entradas identificadas automáticamente en los PDF adjuntos. El verificador confirma que los JSON se pueden analizar, que los códigos son numéricos, que las longitudes corresponden a los niveles contemplados y que no hay códigos duplicados tras deduplicar. **Esto no equivale a una certificación de integridad jurídica ni a una comparación visual línea por línea con el PDF.** Los PDF de comerciantes y financiero incluyen material explicativo y repeticiones; se conserva una sola entrada por código. Las denominaciones partidas en varias líneas pueden necesitar cotejo manual.

## Niveles oficiales y personalizados
- PUC comerciantes: clase (1), grupo (2), cuenta (4), subcuenta (6); el Decreto 2650 contempla auxiliares desde el séptimo dígito según necesidad.
- PUC educación superior 2026: clase (1), grupo (2), cuenta (4), subcuenta (6), desagregación (8).
- Catálogo financiero: clase (1), grupo (2), cuenta (4), subcuenta (6).
- Auxiliares/subauxiliares personalizados se agregan como códigos descendientes de su padre y se almacenan aparte del JSON oficial, sin alterar el catálogo fuente.

## Integración en la aplicación
1. Copiar los archivos `src/` a las rutas equivalentes del repositorio actual, revisando conflictos antes de sobrescribir.
2. Añadir `xlsx` a las dependencias (`package.additions.json` es una referencia; fusionar sus campos con `package.json`, no reemplazarlo).
3. Añadir el script `validate:puc` a `package.json` y ejecutar `npm install` y `npm run validate:puc`.
4. Aplicar la migración SQL en una base de pruebas Supabase después de verificar que `companies` y `company_members` usan los nombres/columnas indicados.
5. Montar `PucAccountManager` en la pantalla de Plan de Cuentas y conectarlo a la empresa activa. Persistir los cambios de `onChange` en `company_puc_accounts`; el componente por sí solo no persiste a nube.
6. Antes de contabilizar, comprobar que la cuenta elegida pertenece al catálogo activo de la empresa y que `isPostable === true`.

## Formato de Excel
Primera hoja con encabezados `codigo`, `nombre`, `padre`. Las cuentas personalizadas deben tener de 7 a 12 dígitos y el código debe comenzar por el código del padre. La importación muestra errores por fila y acepta las filas válidas. Descarga la plantilla desde el propio componente.

## Límites conocidos
Este paquete es una integración focalizada en catálogos y mantenimiento de cuentas, no un reemplazo integral de todo el proyecto Mega Cont IA. La interfaz requiere integrarse en la pantalla existente y conectarse al guardado cloud. No afirmar que los catálogos están certificados hasta cotejar la extracción completa con los PDF oficiales y, en caso necesario, sus versiones publicadas en los sitios oficiales.
