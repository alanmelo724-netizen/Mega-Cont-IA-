# # Mega Cont IA

## Software contable inteligente, automatizado e internacional

**Mega Cont IA** es una plataforma de software contable, administrativo y financiero impulsada por inteligencia artificial.

Su asistente inteligente, **Mega**, está diseñado no solamente para asesorar al usuario, sino también para ejecutar, registrar y automatizar operaciones contables autorizadas, manteniendo validaciones, trazabilidad y controles.

La plataforma debe ser modular, multiempresa y preparada para operar en diferentes países mediante configuraciones contables, tributarias y regulatorias específicas para cada jurisdicción.

> IMPORTANTE: Mega Cont IA se encuentra actualmente en fase de prototipo y desarrollo. Las funciones descritas en este documento no deben considerarse implementadas, certificadas ni legalmente habilitadas hasta que su estado indique expresamente que están funcionales y hayan superado las pruebas correspondientes.

---

# 1. Visión del proyecto

ContaIA Global busca construir una plataforma en la que una empresa pueda:

1. Registrarse.
2. Indicar su país de constitución.
3. Identificar su tipo de entidad.
4. Indicar su actividad económica.
5. Determinar o verificar su tamaño.
6. Determinar el marco contable aplicable.
7. Configurar sus obligaciones tributarias.
8. Seleccionar los módulos que necesita.
9. Parametrizar automáticamente su entorno contable.
10. Utilizar inteligencia artificial para registrar y automatizar operaciones.
11. Generar comprobantes y estados financieros.
12. Analizar la información financiera.
13. Adaptarse progresivamente a diferentes países.

La idea central es:

**Un núcleo contable internacional + módulos regulatorios por país + configuración específica para cada empresa.**

---

# 2. Estado de las funcionalidades

Cada funcionalidad del proyecto deberá identificarse mediante uno de los siguientes estados:

- `DISEÑADA`
- `PROTOTIPO`
- `EN DESARROLLO`
- `FUNCIONAL`
- `EN PRUEBAS`
- `PRODUCCIÓN`

Nunca debe presentarse una función como operativa si solamente existe visualmente.

---

# 3. Funcionalidades actuales del prototipo

Actualmente el prototipo incluye, entre otras funciones:

- Registro básico de empresas.
- Selector de empresa activa.
- Panel principal.
- Registro básico de transacciones.
- Selección manual de cuenta débito.
- Selección manual de cuenta crédito.
- Validación básica de igualdad entre débito y crédito.
- Módulo inicial de asientos contables.
- Estructura inicial para módulos administrativos y contables.

Estas funcionalidades deberán ser auditadas antes de clasificarlas definitivamente como `FUNCIONAL`.

---

# 4. Arquitectura internacional

ContaIA Global no debe asumir que existe un único Plan Único de Cuentas mundial.

Cada empresa tendrá un perfil denominado conceptualmente:

`Company Accounting Profile`

Este perfil deberá contener:

- País.
- Jurisdicción.
- Moneda funcional.
- Tipo de entidad.
- Actividad económica.
- Sector económico.
- Tamaño.
- Marco contable.
- Catálogo de cuentas.
- Configuración tributaria.
- Configuración de nómina.
- Configuración de inventarios.
- Políticas contables.
- Módulos habilitados.
- Fuentes normativas.
- Fecha de vigencia de cada configuración.

La arquitectura debe permitir incorporar nuevos países sin reconstruir el núcleo de ContaIA Global.

---

# 5. Registro inteligente de empresas

Al registrar una empresa, el sistema debe solicitar progresivamente:

## Identificación

- Razón social.
- Nombre comercial.
- País.
- Identificación tributaria.
- Tipo societario.
- Fecha de constitución.
- Domicilio.
- Actividad económica.
- Sector.
- Representante legal, cuando corresponda.

## Clasificación contable

- Tamaño.
- Activos.
- Ingresos.
- Número de empleados.
- Marco contable actual.
- Marco solicitado.
- Entidades de vigilancia o supervisión.
- Información adicional necesaria según el país.

## Obligaciones

El sistema deberá permitir determinar o verificar:

- Obligaciones tributarias.
- Impuestos.
- Retenciones.
- Facturación electrónica.
- Nómina electrónica.
- Obligaciones territoriales.
- Otras obligaciones aplicables.

La IA puede recomendar configuraciones, pero las reglas determinantes deberán proceder de fuentes normativas verificables.

---

# 6. Motor normativo

ContaIA Global deberá disponer de un motor normativo separado del modelo de inteligencia artificial.

Cada regla deberá poder almacenar:

- País.
- Jurisdicción.
- Sector.
- Tipo de entidad.
- Norma.
- Fuente.
- Fecha de publicación.
- Fecha de entrada en vigencia.
- Fecha de finalización, si existe.
- Versión.
- Regla aplicable.
- Estado.
- Evidencia de actualización.

La IA no podrá modificar silenciosamente una regla normativa.

---

# 7. Planes y catálogos de cuentas

Inicialmente, para Colombia, se estudiarán tres categorías documentales.

## 7.1 Comerciantes

PUC tradicional asociado al Decreto 2650 como referencia histórica y estructural.

Su utilización deberá depender de la vigencia, aplicabilidad y configuración correspondiente.

## 7.2 Instituciones de Educación Superior

Catálogo oficial correspondiente a Instituciones de Educación Superior.

Se utilizarán los documentos oficiales que sean suministrados al proyecto.

## 7.3 Sector financiero

Catálogos y estructuras correspondientes al sector financiero bajo las disposiciones y fuentes de la Superintendencia Financiera de Colombia que resulten aplicables.

## Regla fundamental

Los documentos serán adjuntados al proyecto.

**ContaIA Global no deberá inventar cuentas que supuestamente pertenezcan a estos catálogos.**

---

# 8. Importador de catálogos contables

El sistema deberá permitir importar archivos:

- XLSX
- CSV
- Otros formatos estructurados compatibles
- PDF cuando sea técnicamente posible procesarlo de manera fiable

Antes de importar deberá:

1. Analizar el archivo.
2. Identificar columnas.
3. Mostrar una previsualización.
4. Permitir mapear columnas.
5. Detectar duplicados.
6. Detectar códigos inválidos.
7. Detectar jerarquías inconsistentes.
8. Mostrar errores.
9. Solicitar confirmación.
10. Registrar la importación.

---

# 9. Jerarquía contable

El sistema deberá admitir estructuras como:

Clase
→ Grupo
→ Cuenta
→ Subcuenta
→ Auxiliar
→ Subauxiliar

Y permitir niveles adicionales cuando el catálogo utilizado lo requiera.

Los usuarios autorizados podrán crear:

- Cuentas.
- Subcuentas.
- Auxiliares.
- Subauxiliares.

Cada elemento deberá contener como mínimo:

- Código.
- Nombre.
- Cuenta padre.
- Nivel.
- Naturaleza.
- Estado.
- Permiso para recibir movimientos.
- Catálogo.
- Empresa, cuando sea personalizado.

---

# 10. Motor de doble partida

Toda contabilización deberá respetar:

**Total débitos = Total créditos**

El sistema nunca deberá contabilizar definitivamente un asiento descuadrado.

---

# 11. Asientos contables multilínea

Un asiento NO debe limitarse a:

1 débito + 1 crédito.

Debe permitir:

N débitos + N créditos.

Ejemplo conceptual:

| Cuenta | Débito | Crédito |
|---|---:|---:|
| Clientes | 1.190.000 | |
| Ingresos | | 1.000.000 |
| Impuesto correspondiente | | 190.000 |
| TOTAL | 1.190.000 | 1.190.000 |

El ejemplo es ilustrativo y no determina automáticamente el tratamiento tributario aplicable.

Cada asiento deberá contener:

- Empresa.
- Fecha.
- Número.
- Tipo de comprobante.
- Concepto.
- Período.
- Tercero.
- Documento de origen.
- Usuario.
- Estado.
- Líneas contables.
- Adjuntos.
- Historial.

Cada línea podrá contener:

- Cuenta.
- Tercero.
- Descripción.
- Centro de costos.
- Producto.
- Base.
- Impuesto.
- Débito.
- Crédito.

---

# 12. Tipos de comprobantes

El sistema deberá incorporar un catálogo administrable de comprobantes.

Entre ellos:

- Saldos iniciales.
- Apertura.
- Ingreso.
- Egreso.
- Diario.
- Ajustes.
- Reclasificación.
- Cierre.
- Reversión.
- Depreciación.
- Amortización.
- Nómina.
- Inventario.
- Compras.
- Ventas.
- Devoluciones.
- Impuestos.
- Otros comprobantes personalizados.

El usuario deberá poder seleccionar el tipo correspondiente al crear un comprobante.

Los comprobantes podrán manejar:

- Prefijo.
- Consecutivo.
- Serie.
- Numeración.
- Estado.
- Reglas específicas.

---

# 13. Saldos iniciales

Crear un proceso específico para cargar saldos iniciales.

Debe permitir:

- Fecha de corte.
- Cuenta.
- Tercero.
- Débito.
- Crédito.
- Saldo.
- Fuente.
- Archivo de origen.

Debe validar que la información contable se encuentre equilibrada antes de su contabilización.

---

# 14. Ventas

Crear un módulo para:

- Facturas de venta.
- Cotizaciones.
- Pedidos.
- Notas crédito.
- Notas débito.
- Devoluciones.
- Cartera.
- Pagos recibidos.

Cuando corresponda, el documento deberá generar automáticamente su asiento contable.

---

# 15. Compras

Crear funciones para:

- Facturas de compra.
- Órdenes de compra.
- Gastos.
- Proveedores.
- Cuentas por pagar.
- Pagos.
- Devoluciones.
- Notas relacionadas.

Los documentos deberán relacionarse con sus comprobantes y asientos.

---

# 16. Caja y bancos

Incluir:

- Recibos de caja.
- Recibos de ingreso.
- Comprobantes de egreso.
- Comprobantes de pago.
- Cuentas bancarias.
- Movimientos.
- Transferencias.
- Conciliación bancaria.

---

# 17. Productos

Cada producto podrá contener:

- Código.
- Referencia.
- Nombre.
- Descripción.
- Categoría.
- Unidad.
- Tipo.
- Precio.
- Costo.
- Impuestos.
- Cuenta de ingreso.
- Cuenta de inventario.
- Cuenta de costo.
- Existencias.
- Stock mínimo.
- Código de barras.
- Estado.

También deberá existir soporte para servicios.

---

# 18. Importación masiva de productos mediante Excel

ContaIA Global deberá proporcionar una plantilla `.xlsx`.

Flujo:

1. Usuario descarga la plantilla.
2. Completa los productos.
3. Adjunta el archivo.
4. ContaIA analiza el Excel.
5. Presenta una previsualización.
6. Detecta errores.
7. Detecta duplicados.
8. Usuario confirma.
9. Sistema importa.
10. Sistema presenta resultados.

Nunca deberán crearse registros silenciosamente si existen errores importantes.

---

# 19. Inventarios

Debe soportar:

- Bodegas.
- Entradas.
- Salidas.
- Traslados.
- Ajustes.
- Devoluciones.
- Conteos físicos.
- Existencias.
- Costos.
- Historial de movimientos.

Los movimientos deberán relacionarse con los documentos comerciales y contables correspondientes.

---

# 20. Impuestos

Crear un administrador de:

- Impuestos.
- Tarifas.
- Retenciones.
- Bases.
- Cuentas relacionadas.
- Vigencias.
- Reglas.
- Tratamientos especiales.

No asumir que todas las empresas tienen las mismas obligaciones.

---

# 21. Inteligencia artificial operativa

El asistente de ContaIA Global no debe limitarse a responder preguntas.

Debe convertirse progresivamente en un **agente contable operativo**.

Con autorización podrá:

- Crear productos.
- Crear categorías.
- Crear cuentas.
- Crear auxiliares.
- Crear terceros.
- Registrar transacciones.
- Preparar comprobantes.
- Generar asientos.
- Registrar recibos.
- Preparar compras.
- Preparar ventas.
- Registrar pagos.
- Procesar archivos.
- Consultar información.
- Preparar informes.
- Detectar duplicados.
- Identificar inconsistencias.
- Automatizar operaciones repetitivas.

Ejemplo:

Usuario:

“Registra la compra de mercancía de este proveedor según la factura adjunta.”

IA:

1. Lee el documento.
2. Extrae los datos.
3. Identifica el proveedor.
4. Comprueba productos.
5. Consulta reglas.
6. Determina las cuentas propuestas.
7. Calcula el asiento.
8. Ejecuta validaciones.
9. Solicita confirmación cuando corresponda.
10. Registra el documento.
11. Genera el comprobante.
12. Actualiza inventario.
13. Actualiza cuentas por pagar.
14. Actualiza informes.
15. Notifica el resultado.

---

# 22. Seguridad de las acciones de IA

La IA nunca deberá poder saltarse:

- Permisos.
- Validaciones contables.
- Validaciones fiscales.
- Separación entre empresas.
- Períodos cerrados.
- Controles de auditoría.

Las acciones sensibles deberán solicitar confirmación.

Toda acción de IA deberá registrar:

- Usuario.
- Empresa.
- Acción solicitada.
- Acción ejecutada.
- Fecha.
- Resultado.
- Registros afectados.
- Errores.

---

# 23. Sistema de notificaciones

Añadir un icono de campana.

Debe recibir mensajes generados por eventos reales del servidor.

Ejemplos:

- Documento guardado.
- Comprobante contabilizado.
- Importación completada.
- Importación con errores.
- Informe generado.
- Error del sistema.
- Actualización disponible.
- Mantenimiento.
- Acción de IA completada.
- Acción de IA fallida.
- Factura procesada.
- Alertas de inventario.
- Alertas administrativas.

Cada notificación tendrá:

- ID.
- Usuario.
- Empresa.
- Tipo.
- Prioridad.
- Título.
- Mensaje.
- Fecha.
- Estado leído/no leído.
- Recurso relacionado.

---

# 24. Informes financieros

Generar, según corresponda:

- Balance general / Estado de situación financiera.
- Estado de resultados.
- Balance de prueba.
- Libro diario.
- Libro mayor.
- Auxiliares.
- Cuentas por cobrar.
- Cuentas por pagar.
- Flujo de caja.
- Inventarios.
- Compras.
- Ventas.
- Informes tributarios configurados.

---

# 25. Balance mensual y anual

El usuario deberá poder seleccionar:

- Mes.
- Año.
- Intervalo.

Y consultar el informe antes de descargarlo.

---

# 26. Exportación a Excel

Los informes deberán poder descargarse como archivos `.xlsx` reales.

Deberán contener:

- Empresa.
- Identificación.
- Informe.
- Período.
- Fecha de generación.
- Código de cuenta.
- Nombre.
- Jerarquía.
- Saldos.
- Totales.
- Moneda.

---

# 27. Nómina

Diseñar un módulo para:

- Empleados.
- Contratos.
- Conceptos.
- Devengos.
- Deducciones.
- Aportes.
- Provisiones.
- Liquidaciones.
- Comprobantes.
- Contabilización.
- Documentos electrónicos aplicables.

Las reglas deberán estar versionadas y verificadas según la jurisdicción.

---

# 28. Colombia — DIAN

Crear una arquitectura para integrar las funciones electrónicas aplicables con la DIAN.

Entre ellas, según corresponda y de acuerdo con las especificaciones oficiales vigentes:

- Factura electrónica.
- Notas crédito.
- Notas débito.
- Nómina electrónica.
- Documentos electrónicos adicionales soportados por la plataforma.

La arquitectura deberá contemplar:

- Ambiente de pruebas.
- Ambiente de producción.
- Generación de estructuras técnicas.
- Validaciones.
- Firma.
- Transmisión.
- Recepción de respuestas.
- Estados.
- Errores.
- Trazabilidad.

Estados conceptuales:

- Borrador.
- Pendiente.
- Procesando.
- Validado.
- Rechazado.
- Error.

**No afirmar que ContaIA Global está conectado o habilitado por la DIAN hasta que la integración real y el proceso correspondiente se hayan completado.**

Nunca inventar:

- Credenciales.
- Certificados.
- Identificadores fiscales.
- Autorizaciones.
- Respuestas DIAN.
- Estados de aceptación.

Los secretos y certificados deberán mantenerse exclusivamente en infraestructura segura del servidor.

---

# 29. Multiempresa

Cada registro deberá pertenecer a una empresa.

Al cambiar la empresa activa deben cambiar:

- Transacciones.
- Asientos.
- Productos.
- Clientes.
- Proveedores.
- Inventarios.
- Bancos.
- Impuestos.
- Comprobantes.
- Informes.
- Configuración.

Nunca deben mezclarse datos entre empresas.

---

# 30. Usuarios y permisos

Preparar roles como:

- Administrador.
- Contador.
- Auxiliar contable.
- Tesorería.
- Compras.
- Ventas.
- Inventario.
- Consulta.

Los permisos deberán determinar qué puede:

- Consultar.
- Crear.
- Editar.
- Contabilizar.
- Reversar.
- Exportar.
- Aprobar.
- Configurar.

---

# 31. Auditoría

Registrar acciones relevantes.

Ejemplos:

- Creación.
- Modificación.
- Eliminación autorizada.
- Contabilización.
- Reversión.
- Importación.
- Exportación.
- Cambio de configuración.
- Acción ejecutada por IA.
- Cambio de permisos.

Nunca modificar silenciosamente un registro contable contabilizado.

---

# 32. Relación documental

Una operación debe mantener una cadena trazable.

Ejemplo:

Factura
↓
Transacción
↓
Comprobante
↓
Asiento
↓
Líneas contables
↓
Informes financieros

No generar varias contabilizaciones del mismo documento.

Utilizar mecanismos de idempotencia y control de duplicados.

---

# 33. Base de datos

La arquitectura deberá contemplar entidades equivalentes a:

- companies
- users
- company_users
- roles
- permissions
- accounting_frameworks
- chart_of_accounts
- accounts
- tax_rules
- taxes
- third_parties
- products
- product_categories
- warehouses
- inventory_movements
- documents
- invoices
- purchases
- payments
- vouchers
- journal_entries
- journal_entry_lines
- payroll
- notifications
- attachments
- audit_logs
- integrations
- regulatory_rules

Los nombres definitivos dependerán de la arquitectura existente.

---

# 34. Integridad de datos

Utilizar transacciones de base de datos cuando una operación afecte simultáneamente varios registros.

Ejemplo:

Registrar factura
+
actualizar inventario
+
crear cartera
+
crear asiento
+
crear notificación

Si una parte crítica falla, el sistema debe evitar quedar parcialmente contabilizado.

---

# 35. Diseño

La interfaz debe ser:

- Profesional.
- Moderna.
- Sencilla.
- Responsive.
- Comprensible.
- Optimizada para computador.
- Adaptable a tablet.
- Adaptable a celular.

Menú conceptual:

- Inicio.
- IA.
- Transacciones.
- Asientos.
- Comprobantes.
- Ventas.
- Compras.
- Caja y bancos.
- Productos.
- Inventarios.
- Terceros.
- Plan de cuentas.
- Impuestos.
- Nómina.
- DIAN.
- Informes.
- Notificaciones.
- Auditoría.
- Configuración.

---

# 36. Principio fundamental de arquitectura

La inteligencia artificial NO debe ser el libro contable.

Arquitectura:

Usuario
↓
Asistente IA
↓
Herramientas autorizadas
↓
Motor de reglas
↓
Motor contable
↓
Base de datos
↓
Auditoría

La IA interpreta y ejecuta mediante herramientas.

El motor contable valida.

La base de datos conserva.

La auditoría registra.

---

# 37. Principios de seguridad

Nunca:

- Exponer claves privadas.
- Guardar contraseñas sensibles en el frontend.
- Confiar únicamente en controles visuales.
- Permitir acceso cruzado entre empresas.
- Permitir a la IA cambiar sus propios permisos.
- Inventar resultados de integraciones.
- Contabilizar asientos descuadrados.
- Alterar silenciosamente movimientos históricos.

---

# 38. Desarrollo por etapas

## ETAPA 1 — Núcleo contable

Prioridad actual.

Construir y probar:

- Plan de cuentas jerárquico.
- Importación de catálogos.
- Asientos multilínea.
- Comprobantes.
- Saldos iniciales.
- Terceros.
- Auditoría básica.
- Separación multiempresa.

## ETAPA 2 — Operación empresarial

- Productos.
- Excel de productos.
- Inventarios.
- Ventas.
- Compras.
- Caja.
- Bancos.
- Cartera.
- Proveedores.

## ETAPA 3 — IA operativa

Conectar el asistente a herramientas reales para:

- Consultar.
- Crear.
- Registrar.
- Validar.
- Automatizar.
- Generar informes.

## ETAPA 4 — Informes y automatización

- Estados financieros.
- Excel.
- Notificaciones.
- Conciliaciones.
- Automatizaciones.

## ETAPA 5 — Colombia electrónico

- Facturación electrónica.
- Nómina electrónica.
- Integración correspondiente con DIAN.
- Pruebas.
- Habilitación.
- Producción cuando corresponda.

## ETAPA 6 — Internacionalización

Incorporar progresivamente:

- Nuevos países.
- Monedas.
- Marcos contables.
- Catálogos.
- Impuestos.
- Reglas laborales.
- Integraciones gubernamentales.

---

# 39. Regla para desarrolladores y agentes de IA

Antes de realizar cambios:

1. Analizar el repositorio.
2. Revisar la arquitectura existente.
3. Identificar funcionalidades actuales.
4. No eliminar funciones que ya trabajan.
5. Revisar las pruebas existentes.
6. Realizar cambios pequeños y verificables.
7. Crear o actualizar pruebas.
8. Documentar los cambios.
9. Evitar romper compatibilidad innecesariamente.
10. Mantener seguridad y separación multiempresa.

No crear pantallas decorativas que aparenten funciones inexistentes.

---

# 40. Prioridad inmediata del proyecto

La siguiente fase de ContaIA Global será:

**ETAPA 1 — NÚCLEO CONTABLE**

Orden recomendado:

1. Analizar el código actual.
2. Identificar dónde se almacenan actualmente 
