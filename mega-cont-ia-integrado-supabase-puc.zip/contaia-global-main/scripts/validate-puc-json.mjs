import fs from "node:fs";
import path from "node:path";

const dir = "src/data/puc";
const files = fs.readdirSync(dir).filter(f => f.endsWith(".json"));
let failed = false;
for (const file of files) {
  const data = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
  const errors = [];
  const codes = new Set();
  for (const entry of data.entries ?? []) {
    if (!/^\d+$/.test(entry.code)) errors.push(`código no numérico: ${entry.code}`);
    if (codes.has(entry.code)) errors.push(`código duplicado: ${entry.code}`);
    codes.add(entry.code);
    if (!entry.name?.trim()) errors.push(`denominación vacía: ${entry.code}`);
    if (![1, 2, 4, 6, 8].includes(entry.code.length)) errors.push(`longitud de código oficial inesperada: ${entry.code}`);
  }
  const report = { file, entries: data.entries?.length ?? 0, uniqueCodes: codes.size, errors };
  console.log(JSON.stringify(report, null, 2));
  if (errors.length) failed = true;
}
if (failed) process.exit(1);
