import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabaseConfigured = Boolean(url && anonKey && !url.includes("TU-PROYECTO") && !anonKey.includes("TU_CLAVE"));
export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(url!, anonKey!, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    })
  : null;

export type CloudSnapshot = {
  companies: unknown[];
  activeId: string | null;
  lines: unknown[];
  invoices: unknown[];
  items: unknown[];
  employees: unknown[];
  rules: Record<string, unknown>;
  plan: Record<string, unknown>;
  modules: Record<string, unknown>;
  pucCatalogs?: Record<string, unknown>;
};

export async function loadCloudSnapshot(userId: string): Promise<CloudSnapshot | null> {
  if (!supabase) throw new Error("Supabase no está configurado. Completa VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY.");
  const { data, error } = await supabase.from("user_app_state").select("payload").eq("user_id", userId).maybeSingle();
  if (error) throw error;
  return (data?.payload as CloudSnapshot | undefined) ?? null;
}

export async function saveCloudSnapshot(userId: string, payload: CloudSnapshot) {
  if (!supabase) throw new Error("Supabase no está configurado. Completa VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY.");
  const { error } = await supabase.from("user_app_state").upsert({
    user_id: userId,
    payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: "user_id" });
  if (error) throw error;
}
