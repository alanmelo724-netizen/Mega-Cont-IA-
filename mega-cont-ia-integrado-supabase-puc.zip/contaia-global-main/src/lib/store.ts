import { useMemo, useSyncExternalStore } from "react";
import { getCountry } from "./countries";
import type { PucCatalog } from "./pucCatalog";

export type AccountType = "activo" | "pasivo" | "patrimonio" | "ingreso" | "gasto";
export const ACCOUNTS: { code: string; name: string; type: AccountType }[] = [
  { code: "1105", name: "Caja", type: "activo" },
  { code: "1110", name: "Bancos", type: "activo" },
  { code: "1305", name: "Clientes", type: "activo" },
  { code: "1435", name: "Inventario de mercancías", type: "activo" },
  { code: "1524", name: "Equipo de oficina", type: "activo" },
  { code: "2205", name: "Proveedores", type: "pasivo" },
  { code: "2408", name: "Impuestos por pagar", type: "pasivo" },
  { code: "2505", name: "Salarios por pagar", type: "pasivo" },
  { code: "3105", name: "Capital social", type: "patrimonio" },
  { code: "4135", name: "Ventas", type: "ingreso" },
  { code: "4210", name: "Otros ingresos", type: "ingreso" },
  { code: "5105", name: "Gastos de personal", type: "gasto" },
  { code: "5120", name: "Arrendamientos", type: "gasto" },
  { code: "5135", name: "Servicios", type: "gasto" },
  { code: "6135", name: "Costo de ventas", type: "gasto" },
];
export const accountName = (code: string) => {
  const a = ACCOUNTS.find((x) => x.code === code);
  return a ? `${a.code} · ${a.name}` : code;
};

export type ModuleKey = "transacciones" | "asientos" | "facturas" | "inventario" | "nomina" | "asistente" | "reportes";
export type PlanId = "basico" | "profesional" | "empresarial";
export const PLANS: Record<PlanId, { name: string; modules: ModuleKey[] }> = {
  basico: { name: "Básico", modules: ["transacciones", "asientos", "reportes"] },
  profesional: { name: "Profesional", modules: ["transacciones", "asientos", "reportes", "facturas", "asistente"] },
  empresarial: { name: "Empresarial", modules: ["transacciones", "asientos", "reportes", "facturas", "asistente", "inventario", "nomina"] },
};

export type Company = { id: string; name: string; country: string; taxId: string; activity: string; companyType: string; size: string; employees: number; demo: boolean };
export type Line = { id: string; companyId: string; entry: string; date: string; description: string; account: string; debit: number; credit: number; demo: boolean };
export type Invoice = { id: string; companyId: string; number: string; client: string; date: string; subtotal: number; taxRate: number; demo: boolean };
export type Item = { id: string; companyId: string; sku: string; name: string; qty: number; unitCost: number; demo: boolean };
export type Employee = { id: string; companyId: string; name: string; role: string; salary: number; demo: boolean };
export type RuleStatus = "pendiente" | "verificada" | "activa";

type State = {
  companies: Company[];
  activeId: string | null;
  lines: Line[];
  invoices: Invoice[];
  items: Item[];
  employees: Employee[];
  rules: Record<string, Record<string, RuleStatus>>;
  plan: Record<string, PlanId>;
  modules: Record<string, ModuleKey[]>;
  pucCatalogs: Record<string, PucCatalog>;
};

const KEY = "contaia-global-v1";
const uid = () => Math.random().toString(36).slice(2, 10);
const empty: State = { companies: [], activeId: null, lines: [], invoices: [], items: [], employees: [], rules: {}, plan: {}, modules: {}, pucCatalogs: {} };

function demoLines(companyId: string, prefix = "DEMO"): Line[] {
  const d = new Date().toISOString().slice(0, 10);
  const L = (entry: string, description: string, account: string, debit: number, credit: number): Line => ({ id: uid(), companyId, entry: `${prefix}-${entry}`, date: d, description, account, debit, credit, demo: true });
  return [
    L("001", "Aporte de capital inicial (ficticio)", "1110", 50000, 0),
    L("001", "Aporte de capital inicial (ficticio)", "3105", 0, 50000),
    L("002", "Compra de mercancía a crédito (ficticio)", "1435", 12000, 0),
    L("002", "Compra de mercancía a crédito (ficticio)", "2205", 0, 12000),
    L("003", "Venta a crédito (ficticio)", "1305", 8000, 0),
    L("003", "Venta a crédito (ficticio)", "4135", 0, 8000),
    L("004", "Costo de la mercancía vendida (ficticio)", "6135", 4500, 0),
    L("004", "Costo de la mercancía vendida (ficticio)", "1435", 0, 4500),
    L("005", "Causación de nómina del mes (ficticio)", "5105", 3000, 0),
    L("005", "Causación de nómina del mes (ficticio)", "2505", 0, 3000),
    L("006", "Pago de arriendo de oficina (ficticio)", "5120", 1200, 0),
    L("006", "Pago de arriendo de oficina (ficticio)", "1110", 0, 1200),
  ];
}

function seed(): State {
  const id = uid();
  return {
    ...empty,
    activeId: id,
    companies: [{ id, name: "Comercializadora Ejemplo S.A.S. (FICTICIA)", country: "CO", taxId: "000000000-0 (ficticio)", activity: "Comercio al por mayor", companyType: "S.A.S.", size: "Pequeña", employees: 4, demo: true }],
    lines: demoLines(id),
    invoices: [
      { id: uid(), companyId: id, number: "DEMO-F001", client: "Cliente Ficticio Uno", date: new Date().toISOString().slice(0, 10), subtotal: 5000, taxRate: 0, demo: true },
      { id: uid(), companyId: id, number: "DEMO-F002", client: "Cliente Ficticio Dos", date: new Date().toISOString().slice(0, 10), subtotal: 3000, taxRate: 0, demo: true },
    ],
    items: [
      { id: uid(), companyId: id, sku: "DEMO-001", name: "Producto ficticio A", qty: 40, unitCost: 120, demo: true },
      { id: uid(), companyId: id, sku: "DEMO-002", name: "Producto ficticio B", qty: 25, unitCost: 140, demo: true },
    ],
    employees: [
      { id: uid(), companyId: id, name: "Empleado Ficticio 1", role: "Ventas", salary: 900, demo: true },
      { id: uid(), companyId: id, name: "Empleado Ficticio 2", role: "Bodega", salary: 800, demo: true },
      { id: uid(), companyId: id, name: "Empleado Ficticio 3", role: "Administración", salary: 1300, demo: true },
    ],
    plan: { [id]: "empresarial" },
    modules: { [id]: PLANS.empresarial.modules },
  };
}

let state: State = empty;
let loaded = false;
const listeners = new Set<() => void>();
let cloudPersistHandler: ((snapshot: State) => void) | null = null;

/** Register the authenticated cloud persistence callback. */
export function setCloudPersistenceHandler(handler: ((snapshot: State) => void) | null) {
  cloudPersistHandler = handler;
}

/** Snapshot methods are used by the cloud backup/restore screen. */
export function getStoreSnapshot(): State { load(); return structuredClone(state); }
export function replaceStoreSnapshot(snapshot: Partial<State>) {
  load();
  state = { ...empty, ...snapshot };
  if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
  listeners.forEach((l) => l());
}

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    state = raw ? { ...empty, ...JSON.parse(raw) } : seed();
  } catch {
    state = seed();
  }
  localStorage.setItem(KEY, JSON.stringify(state));
}

function set(fn: (s: State) => State) {
  load();
  state = fn(state);
  if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
  listeners.forEach((l) => l());
  cloudPersistHandler?.(structuredClone(state));
}

export function useStore() {
  return useSyncExternalStore(
    (l) => { listeners.add(l); return () => listeners.delete(l); },
    () => { load(); return state; },
    () => empty,
  );
}

/** Datos de la empresa activa, siempre filtrados por companyId. */
export function useCompany() {
  const s = useStore();
  return useMemo(() => {
    const company = s.companies.find((c) => c.id === s.activeId) ?? null;
    const id = company?.id;
    const plan = id ? s.plan[id] ?? "basico" : "basico";
    return {
      company,
      country: getCountry(company?.country),
      lines: s.lines.filter((l) => l.companyId === id),
      invoices: s.invoices.filter((l) => l.companyId === id),
      items: s.items.filter((l) => l.companyId === id),
      employees: s.employees.filter((l) => l.companyId === id),
      rules: id ? s.rules[id] ?? {} : {},
      plan,
      modules: id ? s.modules[id] ?? PLANS[plan].modules : [],
    };
  }, [s]);
}

export const actions = {
  addCompany(c: Omit<Company, "id">, withDemo: boolean) {
    const id = uid();
    set((s) => ({
      ...s,
      activeId: id,
      companies: [...s.companies, { ...c, id, demo: withDemo }],
      lines: withDemo ? [...s.lines, ...demoLines(id)] : s.lines,
      plan: { ...s.plan, [id]: "basico" },
      modules: { ...s.modules, [id]: PLANS.basico.modules },
    }));
  },
  setActive: (id: string) => set((s) => ({ ...s, activeId: id })),
  deleteCompany: (id: string) =>
    set((s) => {
      const keep = <T extends { companyId: string }>(a: T[]) => a.filter((x) => x.companyId !== id);
      const companies = s.companies.filter((c) => c.id !== id);
      return { ...s, companies, activeId: s.activeId === id ? companies[0]?.id ?? null : s.activeId, lines: keep(s.lines), invoices: keep(s.invoices), items: keep(s.items), employees: keep(s.employees) };
    }),
  addLines: (lines: Omit<Line, "id">[]) => set((s) => ({ ...s, lines: [...s.lines, ...lines.map((l) => ({ ...l, id: uid() }))] })),
  deleteEntry: (companyId: string, entry: string) => set((s) => ({ ...s, lines: s.lines.filter((l) => !(l.companyId === companyId && l.entry === entry)) })),
  generateDemoEntries: (companyId: string) => set((s) => ({ ...s, lines: [...s.lines, ...demoLines(companyId, `DEMO${uid().slice(0, 3).toUpperCase()}`)] })),
  addInvoice: (i: Omit<Invoice, "id">) => set((s) => ({ ...s, invoices: [...s.invoices, { ...i, id: uid() }] })),
  addItem: (i: Omit<Item, "id">) => set((s) => ({ ...s, items: [...s.items, { ...i, id: uid() }] })),
  addEmployee: (e: Omit<Employee, "id">) => set((s) => ({ ...s, employees: [...s.employees, { ...e, id: uid() }] })),
  setRule: (companyId: string, ruleId: string, status: RuleStatus) => set((s) => ({ ...s, rules: { ...s.rules, [companyId]: { ...s.rules[companyId], [ruleId]: status } } })),
  setPlan: (companyId: string, plan: PlanId) => set((s) => ({ ...s, plan: { ...s.plan, [companyId]: plan }, modules: { ...s.modules, [companyId]: PLANS[plan].modules } })),
  toggleModule: (companyId: string, m: ModuleKey) =>
    set((s) => {
      const cur = s.modules[companyId] ?? [];
      return { ...s, modules: { ...s.modules, [companyId]: cur.includes(m) ? cur.filter((x) => x !== m) : [...cur, m] } };
    }),
  setPucCatalog: (companyId: string, catalog: PucCatalog) => set((s) => ({ ...s, pucCatalogs: { ...s.pucCatalogs, [companyId]: catalog } })),
  resetDemo: () => { localStorage.removeItem(KEY); loaded = false; set(() => seed()); },
};

export function trialBalance(lines: Line[]) {
  return ACCOUNTS.map((a) => {
    const ls = lines.filter((l) => l.account === a.code);
    const debit = ls.reduce((t, l) => t + l.debit, 0);
    const credit = ls.reduce((t, l) => t + l.credit, 0);
    return { ...a, debit, credit };
  }).filter((r) => r.debit || r.credit);
}

export function financials(lines: Line[]) {
  const tb = trialBalance(lines);
  const sum = (t: AccountType, sign: 1 | -1) => tb.filter((r) => r.type === t).reduce((x, r) => x + sign * (r.debit - r.credit), 0);
  const ingresos = sum("ingreso", -1);
  const gastos = sum("gasto", 1);
  return { ingresos, gastos, activos: sum("activo", 1), pasivos: sum("pasivo", -1), patrimonio: sum("patrimonio", -1), utilidad: ingresos - gastos };
}

export function groupEntries(lines: Line[]) {
  const map = new Map<string, Line[]>();
  lines.forEach((l) => map.set(l.entry, [...(map.get(l.entry) ?? []), l]));
  return [...map.entries()].map(([entry, ls]) => {
    const debit = ls.reduce((t, l) => t + l.debit, 0);
    const credit = ls.reduce((t, l) => t + l.credit, 0);
    return { entry, lines: ls, debit, credit, balanced: Math.abs(debit - credit) < 0.005, demo: ls.some((l) => l.demo) };
  });
}

export const money = (n: number, currency = "USD", locale = "es-CO") =>
  new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 2 }).format(n);
