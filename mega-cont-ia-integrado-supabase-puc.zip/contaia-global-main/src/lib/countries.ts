export type Rule = { id: string; title: string; detail: string };
export type Country = { code: string; name: string; currency: string; locale: string; framework: string; rules: Rule[] };

// Reglas de referencia SIN verificar. Deben ser confirmadas por un profesional
// contable/tributario del país antes de activarse.
export const COUNTRIES: Country[] = [
  { code: "CO", name: "Colombia", currency: "COP", locale: "es-CO", framework: "NIIF (referencia)", rules: [
    { id: "co-iva", title: "IVA tarifa general (referencia 19%)", detail: "Tarifa a confirmar según bien o servicio y normativa vigente." },
    { id: "co-rte", title: "Retención en la fuente", detail: "Bases y porcentajes cambian anualmente; requieren verificación." },
    { id: "co-fe", title: "Facturación electrónica", detail: "Requiere habilitación ante la autoridad tributaria. No integrada en este prototipo." },
  ]},
  { code: "MX", name: "México", currency: "MXN", locale: "es-MX", framework: "NIF (referencia)", rules: [
    { id: "mx-iva", title: "IVA tarifa general (referencia 16%)", detail: "Existen tasas diferenciadas y zonas fronterizas." },
    { id: "mx-cfdi", title: "Comprobantes CFDI", detail: "Requiere proveedor certificado. No integrado." },
  ]},
  { code: "ES", name: "España", currency: "EUR", locale: "es-ES", framework: "PGC (referencia)", rules: [
    { id: "es-iva", title: "IVA tipo general (referencia 21%)", detail: "Existen tipos reducidos y superreducidos." },
    { id: "es-sii", title: "Suministro Inmediato de Información", detail: "Aplica solo a ciertos contribuyentes." },
  ]},
  { code: "CL", name: "Chile", currency: "CLP", locale: "es-CL", framework: "IFRS (referencia)", rules: [
    { id: "cl-iva", title: "IVA (referencia 19%)", detail: "Confirmar exenciones aplicables." },
    { id: "cl-dte", title: "Documentos Tributarios Electrónicos", detail: "No integrado en este prototipo." },
  ]},
  { code: "PE", name: "Perú", currency: "PEN", locale: "es-PE", framework: "NIIF (referencia)", rules: [
    { id: "pe-igv", title: "IGV (referencia 18%)", detail: "Incluye IPM; confirmar vigencia." },
  ]},
  { code: "AR", name: "Argentina", currency: "ARS", locale: "es-AR", framework: "RT FACPCE (referencia)", rules: [
    { id: "ar-iva", title: "IVA alícuota general (referencia 21%)", detail: "Existen alícuotas diferenciales y percepciones." },
  ]},
  { code: "US", name: "Estados Unidos", currency: "USD", locale: "en-US", framework: "US GAAP (referencia)", rules: [
    { id: "us-sales", title: "Sales tax estatal/local", detail: "Varía por estado, condado y ciudad." },
    { id: "us-payroll", title: "Retenciones de nómina federales", detail: "Requieren tablas vigentes." },
  ]},
];

export const getCountry = (code?: string) => COUNTRIES.find((c) => c.code === code) ?? COUNTRIES[0]!;
