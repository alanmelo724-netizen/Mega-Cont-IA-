import { createServerFn } from "@tanstack/react-start";

type Msg = { role: "user" | "assistant"; content: string };

const INSTRUCTIONS = `Eres el asistente contable de ContaIA Global, un PROTOTIPO educativo.
Explica transacciones con lenguaje claro, en español, usando partida doble.
Sugiere clasificaciones contables usando el plan de cuentas genérico de la app cuando aplique.
Reglas: los datos son ficticios de demostración; nunca afirmes cumplimiento legal ni tributario de ningún país;
indica que las tarifas e impuestos deben verificarse con un profesional local. Sé conciso y usa markdown simple.`;

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((input: { messages: Msg[]; context: string }) => {
    if (!Array.isArray(input?.messages) || input.messages.length === 0) throw new Error("Mensajes inválidos");
    return { messages: input.messages.slice(-20).map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) })), context: String(input.context ?? "").slice(0, 8000) };
  })
  .handler(async ({ data }) => {
    const key = process.env['LOVABLE_API_KEY'];
    if (!key) return { error: "El asistente no está configurado." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}`, "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "fetch" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        instructions: `${INSTRUCTIONS}\n\nContexto de la empresa activa:\n${data.context}`,
        input: data.messages,
        reasoning: { effort: "low" },
        store: false,
        stream: true,
      }),
    });
    if (!res.ok || !res.body) {
      if (res.status === 429) return { error: "Demasiadas solicitudes. Intenta de nuevo en unos segundos." };
      if (res.status === 402) return { error: "Se agotaron los créditos de IA del espacio de trabajo." };
      const t = await res.text().catch(() => "");
      return { error: `No se pudo obtener respuesta (${res.status}). ${t.slice(0, 200)}` };
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    let text = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const parts = buf.split("\n");
      buf = parts.pop() ?? "";
      for (const p of parts) {
        if (!p.startsWith("data:")) continue;
        const payload = p.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const ev = JSON.parse(payload);
          if (ev.type === "response.output_text.delta") text += ev.delta;
          if (ev.type === "error" || ev.type === "response.failed") return { error: "El modelo no pudo completar la respuesta." };
        } catch { /* ignore partial */ }
      }
    }
    return { text: text || "Sin respuesta." };
  });
