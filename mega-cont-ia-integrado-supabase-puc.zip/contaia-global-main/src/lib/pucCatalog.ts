export type PucLevel = "clase" | "grupo" | "cuenta" | "subcuenta" | "desagregacion" | "auxiliar" | "subauxiliar";

export interface PucEntry {
  code: string;
  name: string;
  level: PucLevel;
  parentCode: string | null;
  isPostable: boolean;
  custom?: boolean;
  source?: string;
}

export interface PucCatalog {
  schemaVersion: number;
  catalogId: string;
  name: string;
  jurisdiction: string;
  sourceFile: string;
  verificationStatus: string;
  warning: string;
  entries: PucEntry[];
}

export function validateCatalog(catalog: PucCatalog) {
  const errors: string[] = [];
  const seen = new Set<string>();
  const codes = new Set(catalog.entries.map(e => e.code));
  for (const e of catalog.entries) {
    if (!/^\d+$/.test(e.code)) errors.push(`Código no numérico: ${e.code}`);
    if (seen.has(e.code)) errors.push(`Código duplicado: ${e.code}`);
    seen.add(e.code);
    if (!e.name?.trim()) errors.push(`Nombre vacío: ${e.code}`);
    if (!["clase", "grupo", "cuenta", "subcuenta", "desagregacion", "auxiliar", "subauxiliar"].includes(e.level)) {
      errors.push(`Nivel inválido: ${e.code}`);
    }
    if (e.parentCode && !codes.has(e.parentCode)) {
      // Las cuentas auxiliares del usuario pueden estar vinculadas a una cuenta padre
      errors.push(`Padre inexistente (${e.parentCode}) para ${e.code}`);
    }
  }
  return { valid: errors.length === 0, errors, total: catalog.entries.length };
}

export function getPucLevel(code: string, catalogId: string): PucEntry["level"] {
  if (catalogId === "educacion-superior") {
    if (code.length === 1) return "clase";
    if (code.length === 2) return "grupo";
    if (code.length === 4) return "cuenta";
    if (code.length === 6) return "subcuenta";
    if (code.length === 8) return "desagregacion";
    return code.length === 9 ? "auxiliar" : "subauxiliar";
  }
  if (code.length === 1) return "clase";
  if (code.length === 2) return "grupo";
  if (code.length === 4) return "cuenta";
  if (code.length === 6) return "subcuenta";
  return code.length === 7 ? "auxiliar" : "subauxiliar";
}

export function addCustomAccount(catalog: PucCatalog, input: { code: string; name: string; parentCode: string }) {
  const code = input.code.trim();
  const name = input.name.trim();
  const parentCode = input.parentCode.trim();
  if (!/^\d{7,12}$/.test(code)) throw new Error("Las cuentas personalizadas deben tener entre 7 y 12 dígitos.");
  if (!name) throw new Error("Escribe la denominación de la cuenta.");
  if (catalog.entries.some(e => e.code === code)) throw new Error("Ese código ya existe en el catálogo.");
  const parent = catalog.entries.find(e => e.code === parentCode);
  if (!parent) throw new Error("Selecciona una cuenta padre existente.");
  if (!code.startsWith(parentCode) || code.length <= parentCode.length) {
    throw new Error("El código debe comenzar con el código de la cuenta padre y ser más largo.");
  }
  const childAlreadyExists = catalog.entries.some(e => e.code.startsWith(code) && e.code.length > code.length);
  catalog.entries.push({
    code, name, parentCode, level: getPucLevel(code, catalog.catalogId),
    isPostable: !childAlreadyExists, custom: true, source: "Creada por usuario"
  });
  // Un padre con hijos ya no se puede contabilizar directamente.
  catalog.entries.forEach(e => {
    if (e.code !== code && e.code.startsWith(parentCode) && e.code.length < code.length) e.isPostable = false;
  });
  return catalog;
}

export function validateImportRows(rows: Array<Record<string, unknown>>, catalog: PucCatalog) {
  const errors: string[] = [];
  const accepted: PucEntry[] = [];
  const existing = new Set(catalog.entries.map(e => e.code));
  rows.forEach((row, index) => {
    const code = String(row.codigo ?? row.code ?? "").trim();
    const name = String(row.nombre ?? row.name ?? "").trim();
    const parentCode = String(row.padre ?? row.parentCode ?? "").trim();
    if (!/^\d{7,12}$/.test(code)) { errors.push(`Fila ${index + 2}: código debe tener 7–12 dígitos.`); return; }
    if (!name) { errors.push(`Fila ${index + 2}: falta nombre.`); return; }
    if (existing.has(code)) { errors.push(`Fila ${index + 2}: código ${code} ya existe.`); return; }
    if (!parentCode || !existing.has(parentCode) && !accepted.some(e => e.code === parentCode)) {
      errors.push(`Fila ${index + 2}: padre ${parentCode || "(vacío)"} no existe en catálogo ni en el archivo.`); return;
    }
    if (!code.startsWith(parentCode) || code.length <= parentCode.length) {
      errors.push(`Fila ${index + 2}: ${code} no desciende del padre ${parentCode}.`); return;
    }
    existing.add(code);
    accepted.push({ code, name, parentCode, level: getPucLevel(code, catalog.catalogId), isPostable: true, custom: true, source: "Importación Excel" });
  });
  return { accepted, errors };
}
