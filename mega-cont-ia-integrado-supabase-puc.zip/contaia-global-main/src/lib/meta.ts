export const meta = (title: string, description: string) => ({
  meta: [
    { title: `${title} · ContaIA Global` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} · ContaIA Global` },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ],
});
