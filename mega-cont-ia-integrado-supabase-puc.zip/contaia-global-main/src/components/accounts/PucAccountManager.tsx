import { useMemo, useState } from "react";
import * as XLSX from "xlsx";
import type { PucCatalog, PucEntry } from "../../lib/pucCatalog";
import { addCustomAccount, validateImportRows } from "../../lib/pucCatalog";

type Props = {
  catalog: PucCatalog;
  onChange: (catalog: PucCatalog) => void;
};

/** Gestor de cuentas personalizadas. Persistir onChange en el backend de la empresa activa. */
export default function PucAccountManager({ catalog, onChange }: Props) {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [parentCode, setParentCode] = useState("");
  const [query, setQuery] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<string[]>([]);
  const rows = useMemo(() => catalog.entries.filter(e =>
    `${e.code} ${e.name}`.toLocaleLowerCase().includes(query.toLocaleLowerCase())
  ).slice(0, 250), [catalog.entries, query]);

  function createAccount() {
    try {
      const next = structuredClone(catalog);
      addCustomAccount(next, { code, name, parentCode });
      onChange(next);
      setCode(""); setName(""); setParentCode(""); setMessage("Cuenta añadida al catálogo de esta empresa.");
      setErrors([]);
    } catch (error) {
      setMessage("");
      setErrors([error instanceof Error ? error.message : "No se pudo crear la cuenta."]);
    }
  }

  async function importExcel(file?: File) {
    if (!file) return;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
      const result = validateImportRows(data, catalog);
      setErrors(result.errors);
      if (!result.accepted.length) {
        setMessage(`No se importaron cuentas. Filas revisadas: ${data.length}.`);
        return;
      }
      const next = structuredClone(catalog);
      // Iterative insertion preserves parent-child ordering and recalculates postable status.
      for (const item of result.accepted) {
        next.entries.push(item);
        next.entries.forEach(e => {
          if (e.code !== item.code && item.code.startsWith(e.code)) e.isPostable = false;
        });
      }
      onChange(next);
      setMessage(`Importadas ${result.accepted.length} cuentas. Revisa los errores de las filas rechazadas, si los hay.`);
    } catch {
      setMessage("No se pudo leer el archivo. Usa .xlsx o .xls con columnas codigo, nombre y padre.");
    }
  }

  function downloadTemplate() {
    const data = [
      { codigo: "1105051", nombre: "Auxiliar ejemplo", padre: "110505" },
      { codigo: "11050511", nombre: "Subauxiliar ejemplo", padre: "1105051" }
    ];
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Cuentas");
    XLSX.writeFile(wb, "plantilla_cuentas_mega_cont_ia.xlsx");
  }

  return <section className="space-y-4 rounded-xl border p-4">
    <header>
      <h2 className="text-lg font-semibold">Plan de cuentas de la empresa</h2>
      <p className="text-sm text-muted-foreground">{catalog.name}</p>
      <p className="text-sm">{catalog.entries.length.toLocaleString()} códigos cargados en este catálogo.</p>
    </header>

    <div className="grid gap-3 md:grid-cols-2">
      <label className="space-y-1 text-sm">Código de la nueva cuenta
        <input className="w-full rounded border p-2" value={code} onChange={e => setCode(e.target.value)} inputMode="numeric" placeholder="Ej. 1105051" />
      </label>
      <label className="space-y-1 text-sm">Denominación
        <input className="w-full rounded border p-2" value={name} onChange={e => setName(e.target.value)} placeholder="Nombre de la cuenta" />
      </label>
      <label className="space-y-1 text-sm md:col-span-2">Código de la cuenta padre
        <input className="w-full rounded border p-2" value={parentCode} onChange={e => setParentCode(e.target.value)} placeholder="Selecciona/pega un código existente, ej. 110505" />
      </label>
    </div>
    <button type="button" className="rounded bg-primary px-4 py-2 text-primary-foreground" onClick={createAccount}>Crear cuenta</button>

    <div className="flex flex-wrap items-center gap-2">
      <button type="button" className="rounded border px-3 py-2" onClick={downloadTemplate}>Descargar plantilla Excel</button>
      <label className="cursor-pointer rounded border px-3 py-2">
        Importar Excel (.xlsx/.xls)
        <input type="file" accept=".xlsx,.xls" className="hidden" onChange={e => importExcel(e.target.files?.[0])} />
      </label>
    </div>
    <p className="text-xs text-muted-foreground">Columnas requeridas: codigo, nombre, padre. Los códigos oficiales del catálogo se conservan; las cuentas personalizadas se guardan separadas como creación del usuario.</p>
    {message && <p role="status" className="text-sm">{message}</p>}
    {errors.length > 0 && <div role="alert" className="rounded border border-destructive p-3 text-sm">
      <strong>Filas que necesitan corrección ({errors.length})</strong>
      <ul className="list-disc pl-5">{errors.slice(0, 30).map((error, i) => <li key={`${i}-${error}`}>{error}</li>)}</ul>
      {errors.length > 30 && <p>Se muestran los primeros 30 errores.</p>}
    </div>}

    <label className="block space-y-1 text-sm">Buscar cuenta
      <input className="w-full rounded border p-2" value={query} onChange={e => setQuery(e.target.value)} placeholder="Código o nombre" />
    </label>
    <div className="max-h-96 overflow-auto rounded border">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-muted"><tr><th className="p-2 text-left">Código</th><th className="p-2 text-left">Nombre</th><th className="p-2 text-left">Nivel</th><th className="p-2 text-left">Uso</th></tr></thead>
        <tbody>{rows.map((entry: PucEntry) => <tr key={entry.code} className="border-t">
          <td className="p-2 font-mono">{entry.code}</td><td className="p-2">{entry.name}</td><td className="p-2">{entry.level}</td>
          <td className="p-2">{entry.isPostable ? "Contabilizable" : "Agrupadora"}{entry.custom ? " · Personalizada" : ""}</td>
        </tr>)}</tbody>
      </table>
      {catalog.entries.length > rows.length && <p className="p-2 text-xs text-muted-foreground">Se muestran hasta 250 resultados; usa el buscador para filtrar.</p>}
    </div>
  </section>;
}
