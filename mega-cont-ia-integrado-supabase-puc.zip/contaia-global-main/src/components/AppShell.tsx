import { Link, useRouterState } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { BarChart3, Bot, Building2, Calculator, FileText, Globe2, LayoutDashboard, ListOrdered, Menu, Package, Settings2, Users, X, BookOpen, Database } from "lucide-react";
import { useCompany, useStore, actions, type ModuleKey } from "@/lib/store";

const NAV: { to: string; label: string; icon: typeof Menu; module?: ModuleKey }[] = [
  { to: "/", label: "Panel financiero", icon: LayoutDashboard },
  { to: "/empresas", label: "Empresas", icon: Building2 },
  { to: "/configuracion", label: "Configuración país", icon: Globe2 },
  { to: "/transacciones", label: "Transacciones", icon: ListOrdered, module: "transacciones" },
  { to: "/asientos", label: "Asientos contables", icon: BookOpen, module: "asientos" },
  { to: "/plan-cuentas", label: "Plan de cuentas", icon: BookOpen },
  { to: "/facturas", label: "Facturas", icon: FileText, module: "facturas" },
  { to: "/inventario", label: "Inventario", icon: Package, module: "inventario" },
  { to: "/nomina", label: "Nómina", icon: Users, module: "nomina" },
  { to: "/asistente", label: "Asistente IA", icon: Bot, module: "asistente" },
  { to: "/reportes", label: "Reportes", icon: BarChart3, module: "reportes" },
  { to: "/plan", label: "Plan y módulos", icon: Settings2 },
  { to: "/nube", label: "Base de datos y respaldos", icon: Database },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { company, modules } = useCompany();
  const { companies } = useStore();
  const items = NAV.filter((n) => !n.module || modules.includes(n.module));

  const nav = (
    <nav className="flex flex-col gap-0.5">
      {items.map((n) => {
        const active = n.to === "/" ? path === "/" : path.startsWith(n.to);
        return (
          <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${active ? "bg-sidebar-accent text-primary-foreground" : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60"}`}>
            <n.icon className="h-4 w-4" /> {n.label}
          </Link>
        );
      })}
    </nav>
  );

  const brand = (
    <div className="flex items-center gap-2">
      <div className="grid h-8 w-8 place-items-center rounded-md bg-primary text-primary-foreground"><Calculator className="h-4 w-4" /></div>
      <div className="leading-tight">
        <div className="font-display text-sm font-semibold text-primary-foreground">Mega Cont IA</div>
        <div className="text-[11px] text-sidebar-foreground/60">Contabilidad inteligente</div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:flex">
      <aside className="hidden w-64 shrink-0 flex-col gap-6 bg-sidebar p-4 lg:sticky lg:top-0 lg:flex lg:h-screen">
        {brand}
        {nav}
      </aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-foreground/40" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 flex h-full w-72 flex-col gap-6 overflow-y-auto bg-sidebar p-4">
            <div className="flex items-center justify-between">{brand}<button aria-label="Cerrar menú" onClick={() => setOpen(false)} className="text-sidebar-foreground"><X className="h-5 w-5" /></button></div>
            {nav}
          </aside>
        </div>
      )}
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b bg-card/95 px-4 py-3 backdrop-blur">
          <button aria-label="Abrir menú" className="lg:hidden" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
          <div className="min-w-0 flex-1">
            {companies.length > 0 ? (
              <select aria-label="Empresa activa" className="field max-w-xs truncate py-1.5" value={company?.id ?? ""} onChange={(e) => actions.setActive(e.target.value)}>
                {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            ) : <span className="text-sm text-muted-foreground">Sin empresas registradas</span>}
          </div>
        </header>
        <div className="border-b bg-warning px-4 py-1.5 text-xs text-warning-foreground">
          Prototipo demostrativo. Los datos marcados como DEMO son ficticios. No sustituye asesoría contable ni garantiza cumplimiento legal en ningún país.
        </div>
        <main className="mx-auto max-w-6xl p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({ title, desc, children }: { title: string; desc?: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {desc && <p className="mt-1 text-sm text-muted-foreground">{desc}</p>}
      </div>
      {children && <div className="flex flex-wrap gap-2">{children}</div>}
    </div>
  );
}

export const DemoBadge = () => <span className="rounded bg-warning px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-warning-foreground">Demo · ficticio</span>;

export function NeedCompany({ children }: { children: ReactNode }) {
  const { company } = useCompany();
  if (!company) return (
    <div className="panel p-8 text-center">
      <p className="text-sm text-muted-foreground">Registra o selecciona una empresa para continuar.</p>
      <Link to="/empresas" className="btn btn-primary mt-4">Ir a Empresas</Link>
    </div>
  );
  return <>{children}</>;
}

export function ModuleGate({ module, children }: { module: ModuleKey; children: ReactNode }) {
  const { modules } = useCompany();
  if (!modules.includes(module)) return (
    <div className="panel p-8 text-center">
      <p className="text-sm text-muted-foreground">Este módulo está desactivado para el plan actual de la empresa.</p>
      <Link to="/plan" className="btn btn-primary mt-4">Gestionar plan</Link>
    </div>
  );
  return <>{children}</>;
}
