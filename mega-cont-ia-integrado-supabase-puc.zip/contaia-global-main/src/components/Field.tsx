import type { ReactNode } from "react";
export function L({ t, children }: { t: string; children: ReactNode }) {
  return <label className="grid gap-1 text-sm"><span className="text-muted-foreground">{t}</span>{children}</label>;
}
