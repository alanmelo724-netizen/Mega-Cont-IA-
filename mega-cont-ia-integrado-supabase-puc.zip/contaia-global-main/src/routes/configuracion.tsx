import { createFileRoute } from "@tanstack/react-router";
import { NeedCompany, PageHeader } from "@/components/AppShell";
import { actions, useCompany, type RuleStatus } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/configuracion")({
  head: () => meta("Configuración por país", "Reglas contables y tributarias de referencia pendientes de verificación."),
  component: Config,
});

const label: Record<RuleStatus, string> = { pendiente: "Pendiente de verificación", verificada: "Verificada", activa: "Activa" };
const tone: Record<RuleStatus, string> = { pendiente: "bg-warning text-warning-foreground", verificada: "bg-accent text-accent-foreground", activa: "bg-success text-primary-foreground" };

function Config() {
  const { company, country, rules } = useCompany();
  return (
    <NeedCompany>
      <PageHeader title="Configuración contable" desc={`${country.name} · Moneda ${country.currency} · Marco ${country.framework}`} />
      <div className="panel mb-4 p-4 text-sm text-muted-foreground">
        Estas reglas son referencias iniciales y pueden estar desactualizadas. Un profesional debe verificarlas antes de activarlas. La aplicación no garantiza el cumplimiento de obligaciones legales.
      </div>
      <div className="grid gap-3">
        {country.rules.map((r) => {
          const st = rules[r.id] ?? "pendiente";
          return (
            <div key={r.id} className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2 font-medium">{r.title}<span className={`rounded px-1.5 py-0.5 text-[11px] ${tone[st]}`}>{label[st]}</span></div>
                <p className="mt-1 text-sm text-muted-foreground">{r.detail}</p>
              </div>
              <div className="flex gap-2">
                {st === "pendiente" && <button className="btn btn-outline" onClick={() => actions.setRule(company!.id, r.id, "verificada")}>Marcar verificada</button>}
                {st === "verificada" && <button className="btn btn-primary" onClick={() => actions.setRule(company!.id, r.id, "activa")}>Activar</button>}
                {st !== "pendiente" && <button className="btn btn-outline" onClick={() => actions.setRule(company!.id, r.id, "pendiente")}>Revertir</button>}
              </div>
            </div>
          );
        })}
      </div>
    </NeedCompany>
  );
}
