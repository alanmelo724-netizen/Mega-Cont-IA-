import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { NeedCompany, PageHeader } from "@/components/AppShell";
import PucAccountManager from "@/components/accounts/PucAccountManager";
import comercial from "@/data/puc/comercial.json";
import educacionSuperior from "@/data/puc/educacion-superior.json";
import financiero from "@/data/puc/financiero.json";
import type { PucCatalog } from "@/lib/pucCatalog";
import { actions, useCompany, useStore } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/plan-cuentas")({
  head: () => meta("Plan de cuentas", "Catálogos PUC y cuentas personalizadas por empresa."),
  component: PlanCuentas,
});

const CATALOGS: Record<string, PucCatalog> = {
  comercial: comercial as PucCatalog,
  "educacion-superior": educacionSuperior as PucCatalog,
  financiero: financiero as PucCatalog,
};

function PlanCuentas() {
  const { company } = useCompany();
  const store = useStore();
  const [catalogId, setCatalogId] = useState("comercial");
  const storageKey = company ? `${company.id}:${catalogId}` : "";
  const catalog = useMemo(() => {
    const saved = storageKey ? store.pucCatalogs[storageKey] : undefined;
    return (saved ?? CATALOGS[catalogId]) as PucCatalog;
  }, [store.pucCatalogs, storageKey, catalogId]);

  return <NeedCompany>
    <PageHeader title="Plan de cuentas" desc="Selecciona el catálogo que corresponda a la actividad y normativa aplicable a la empresa." />
    <div className="panel mb-4 p-4">
      <label className="block space-y-1 text-sm font-medium">Catálogo contable
        <select className="field mt-1 w-full max-w-xl" value={catalogId} onChange={e => setCatalogId(e.target.value)}>
          <option value="comercial">PUC comerciantes · Decreto 2650 de 1993 (referencia histórica)</option>
          <option value="educacion-superior">PUC de educación superior · catálogo suministrado</option>
          <option value="financiero">Catálogo financiero · catálogo suministrado</option>
        </select>
      </label>
      <p className="mt-2 text-xs text-muted-foreground">Advertencia: los archivos JSON pasaron validaciones estructurales; el cotejo completo línea por línea contra los PDF y la vigencia normativa deben verificarse antes de usar estos catálogos en producción.</p>
    </div>
    {company && <PucAccountManager key={`${company.id}:${catalogId}`} catalog={catalog} onChange={next => actions.setPucCatalog(storageKey, next)} />}
  </NeedCompany>;
}
