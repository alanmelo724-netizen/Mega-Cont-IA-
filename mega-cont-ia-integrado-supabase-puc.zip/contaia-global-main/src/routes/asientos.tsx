import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, Plus, Trash2, XCircle } from "lucide-react";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { ACCOUNTS, accountName, actions, groupEntries, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/asientos")({
  head: () => meta("Asientos contables", "Asientos de ejemplo y validación de débitos contra créditos."),
  component: Asientos,
});

type Row = { account: string; debit: number; credit: number };

function Asientos() {
  const { company, lines, country } = useCompany();
  const entries = groupEntries(lines);
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const [desc, setDesc] = useState("");
  const [rows, setRows] = useState<Row[]>([{ account: "1110", debit: 0, credit: 0 }, { account: "4135", debit: 0, credit: 0 }]);
  const td = rows.reduce((t, r) => t + r.debit, 0);
  const tc = rows.reduce((t, r) => t + r.credit, 0);
  const ok = td > 0 && Math.abs(td - tc) < 0.005 && desc;
  const setRow = (i: number, p: Partial<Row>) => setRows(rows.map((r, j) => (j === i ? { ...r, ...p } : r)));
  const save = () => {
    if (!ok || !company) return;
    const entry = `AS-${Date.now().toString().slice(-6)}`;
    const date = new Date().toISOString().slice(0, 10);
    actions.addLines(rows.filter((r) => r.debit || r.credit).map((r) => ({ ...r, companyId: company.id, entry, date, description: desc, demo: false })));
    setDesc(""); setRows([{ account: "1110", debit: 0, credit: 0 }, { account: "4135", debit: 0, credit: 0 }]);
  };
  return (
    <NeedCompany><ModuleGate module="asientos">
      <PageHeader title="Asientos contables" desc="El sistema solo guarda asientos donde débitos = créditos.">
        <button className="btn btn-outline" onClick={() => actions.generateDemoEntries(company!.id)}>Generar asientos de ejemplo (ficticios)</button>
      </PageHeader>
      <div className="panel mb-6 p-5">
        <h2 className="mb-3 font-semibold">Nuevo asiento compuesto</h2>
        <input className="field mb-3" placeholder="Descripción del asiento" value={desc} onChange={(e) => setDesc(e.target.value)} />
        <div className="grid gap-2">
          {rows.map((r, i) => (
            <div key={i} className="grid grid-cols-[1fr_auto] gap-2 sm:grid-cols-[2fr_1fr_1fr_auto]">
              <select className="field col-span-2 sm:col-span-1" value={r.account} onChange={(e) => setRow(i, { account: e.target.value })}>{ACCOUNTS.map((a) => <option key={a.code} value={a.code}>{a.code} {a.name}</option>)}</select>
              <input type="number" min={0} placeholder="Débito" className="field num" value={r.debit || ""} onChange={(e) => setRow(i, { debit: Number(e.target.value), credit: 0 })} />
              <input type="number" min={0} placeholder="Crédito" className="field num" value={r.credit || ""} onChange={(e) => setRow(i, { credit: Number(e.target.value), debit: 0 })} />
              <button aria-label="Quitar línea" className="btn btn-outline" onClick={() => rows.length > 2 && setRows(rows.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button className="btn btn-outline" onClick={() => setRows([...rows, { account: "5135", debit: 0, credit: 0 }])}><Plus className="h-4 w-4" />Línea</button>
          <span className="num text-sm">Débitos {fmt(td)} · Créditos {fmt(tc)}</span>
          <span className={`flex items-center gap-1 text-sm ${Math.abs(td - tc) < 0.005 && td > 0 ? "text-success" : "text-destructive"}`}>
            {Math.abs(td - tc) < 0.005 && td > 0 ? <><CheckCircle2 className="h-4 w-4" />Cuadrado</> : <><XCircle className="h-4 w-4" />Diferencia {fmt(td - tc)}</>}
          </span>
          <button className="btn btn-primary ml-auto" disabled={!ok} onClick={save}>Guardar asiento</button>
        </div>
      </div>
      <div className="grid gap-3">
        {[...entries].reverse().map((e) => (
          <div key={e.entry} className="panel overflow-x-auto">
            <div className="flex flex-wrap items-center gap-2 border-b px-4 py-2 text-sm">
              <span className="font-medium">{e.entry}</span>{e.demo && <DemoBadge />}
              <span className="text-muted-foreground">{e.lines[0]?.description}</span>
              <span className={`ml-auto text-xs font-medium ${e.balanced ? "text-success" : "text-destructive"}`}>{e.balanced ? "✓ Débitos = Créditos" : "✗ Descuadrado"}</span>
              <button aria-label="Eliminar asiento" className="text-muted-foreground hover:text-destructive" onClick={() => actions.deleteEntry(company!.id, e.entry)}><Trash2 className="h-4 w-4" /></button>
            </div>
            <table className="tbl">
              <tbody>
                {e.lines.map((l) => <tr key={l.id}><td>{accountName(l.account)}</td><td className="num text-right">{l.debit ? fmt(l.debit) : ""}</td><td className="num text-right">{l.credit ? fmt(l.credit) : ""}</td></tr>)}
                <tr className="font-medium"><td>Total</td><td className="num text-right">{fmt(e.debit)}</td><td className="num text-right">{fmt(e.credit)}</td></tr>
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </ModuleGate></NeedCompany>
  );
}
