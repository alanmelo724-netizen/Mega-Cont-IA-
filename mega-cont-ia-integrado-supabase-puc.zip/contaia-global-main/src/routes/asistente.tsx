import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { Calculator, Loader2, Send } from "lucide-react";
import { ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { askAssistant } from "@/lib/ai.functions";
import { ACCOUNTS, accountName, groupEntries, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export const Route = createFileRoute("/asistente")({
  validateSearch: (s: Record<string, unknown>) => ({ tx: typeof s['tx'] === "string" ? s['tx'] : undefined }),
  head: () => meta("Asistente IA", "Explicación de transacciones y sugerencias de clasificación contable."),
  component: Asistente,
});

type Msg = { role: "user" | "assistant"; content: string };

function Asistente() {
  const { tx } = Route.useSearch();
  const { company, country, lines } = useCompany();
  const ask = useServerFn(askAssistant);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const asked = useRef(false);
  const entries = groupEntries(lines);

  const context = `Empresa: ${company?.name} (${country.name}, ${country.currency}, ${company?.activity}). Datos ficticios: ${lines.some((l) => l.demo) ? "sí" : "no"}.
Plan de cuentas: ${ACCOUNTS.map((a) => `${a.code} ${a.name} (${a.type})`).join("; ")}.
Últimos asientos: ${entries.slice(-8).map((e) => `${e.entry}: ${e.lines[0]?.description} -> ${e.lines.map((l) => `${accountName(l.account)} D${l.debit} C${l.credit}`).join(", ")}`).join(" | ")}`;

  const send = async (text: string) => {
    if (!text.trim() || busy) return;
    const next = [...msgs, { role: "user" as const, content: text }];
    setMsgs(next); setInput(""); setBusy(true); setErr("");
    try {
      const r = await ask({ data: { messages: next, context } });
      if ("error" in r && r.error) setErr(r.error);
      else setMsgs([...next, { role: "assistant", content: r.text ?? "" }]);
    } catch { setErr("No se pudo contactar al asistente."); }
    setBusy(false);
  };

  useEffect(() => {
    if (!tx || asked.current || !company) return;
    const e = entries.find((x) => x.entry === tx);
    if (!e) return;
    asked.current = true;
    send(`Explícame el asiento ${e.entry} "${e.lines[0]?.description}": ${e.lines.map((l) => `${accountName(l.account)} débito ${l.debit} crédito ${l.credit}`).join("; ")}. ¿Es correcta la clasificación?`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tx, company?.id, entries.length]);

  const suggestions = ["Clasifica: pago de servicio de internet de la oficina", "Explica el último asiento registrado", "¿Qué diferencia hay entre activo y gasto?"];

  return (
    <NeedCompany><ModuleGate module="asistente">
      <PageHeader title="Asistente contable IA" desc="Sugerencias orientativas. Verifica siempre con un profesional contable." />
      <div className="panel flex h-[65vh] flex-col">
        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {!msgs.length && (
            <div className="grid gap-2">
              <p className="text-sm text-muted-foreground">Prueba con:</p>
              {suggestions.map((s) => <button key={s} onClick={() => send(s)} className="btn btn-outline justify-start text-left">{s}</button>)}
            </div>
          )}
          {msgs.map((m, i) => m.role === "user" ? (
            <div key={i} className="ml-auto max-w-[85%] rounded-lg bg-sidebar px-3 py-2 text-sm text-primary-foreground">{m.content}</div>
          ) : (
            <div key={i} className="flex max-w-[95%] gap-2">
              <div className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-accent text-accent-foreground"><Calculator className="h-4 w-4" /></div>
              <div className="min-w-0 space-y-2 overflow-x-auto text-sm leading-relaxed [&_h3]:font-semibold [&_li]:ml-4 [&_li]:list-disc [&_table]:tbl"><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown></div>
            </div>
          ))}
          {busy && <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Analizando…</div>}
          {err && <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{err}</div>}
        </div>
        <form className="flex gap-2 border-t p-3" onSubmit={(e) => { e.preventDefault(); send(input); }}>
          <input className="field" placeholder="Describe una transacción o haz una pregunta…" value={input} onChange={(e) => setInput(e.target.value)} />
          <button aria-label="Enviar" className="btn btn-primary" disabled={busy || !input.trim()}><Send className="h-4 w-4" /></button>
        </form>
      </div>
    </ModuleGate></NeedCompany>
  );
}
