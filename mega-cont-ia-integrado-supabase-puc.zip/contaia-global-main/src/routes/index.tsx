import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDownRight, ArrowUpRight, Landmark, Scale, Wallet } from "lucide-react";
import { DemoBadge, NeedCompany, PageHeader } from "@/components/AppShell";
import { financials, groupEntries, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/")({
  head: () => meta("Panel financiero", "Ingresos, gastos, activos, pasivos y utilidad de la empresa activa."),
  component: Dashboard,
});

function Dashboard() {
  const { company, lines, country } = useCompany();
  const f = financials(lines);
  const entries = groupEntries(lines);
  const unbalanced = entries.filter((e) => !e.balanced).length;
  const hasDemo = lines.some((l) => l.demo);
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const cards = [
    { label: "Ingresos", value: f.ingresos, icon: ArrowUpRight },
    { label: "Gastos", value: f.gastos, icon: ArrowDownRight },
    { label: "Activos", value: f.activos, icon: Wallet },
    { label: "Pasivos", value: f.pasivos, icon: Landmark },
    { label: "Utilidad del periodo", value: f.utilidad, icon: Scale },
  ];
  return (
    <NeedCompany>
      <PageHeader title="Panel financiero" desc={`${company?.name} · ${country.name} · ${country.currency}`}>
        {hasDemo && <DemoBadge />}
      </PageHeader>
      {hasDemo && <p className="mb-4 text-xs text-muted-foreground">Cifras calculadas a partir de transacciones ficticias de demostración. No representan información financiera real.</p>}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="panel p-4">
            <div className="flex items-center justify-between text-xs text-muted-foreground">{c.label}<c.icon className="h-4 w-4 text-primary" /></div>
            <div className={`num mt-2 text-lg font-medium ${c.value < 0 ? "text-destructive" : ""}`}>{fmt(c.value)}</div>
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="panel p-5">
          <h2 className="font-semibold">Estado de la partida doble</h2>
          <p className="mt-2 text-sm text-muted-foreground">{entries.length} asientos registrados.</p>
          <p className={`mt-2 text-sm font-medium ${unbalanced ? "text-destructive" : "text-success"}`}>
            {unbalanced ? `${unbalanced} asiento(s) descuadrado(s)` : "Todos los asientos cuadran (débitos = créditos)"}
          </p>
          <Link to="/asientos" className="btn btn-outline mt-4">Ver asientos</Link>
        </div>
        <div className="panel p-5">
          <h2 className="font-semibold">Ecuación contable</h2>
          <p className="num mt-3 text-sm">Activos {fmt(f.activos)}</p>
          <p className="num text-sm">Pasivos + Patrimonio + Utilidad {fmt(f.pasivos + f.patrimonio + f.utilidad)}</p>
          <Link to="/reportes" className="btn btn-outline mt-4">Ver reportes</Link>
        </div>
      </div>
    </NeedCompany>
  );
}
