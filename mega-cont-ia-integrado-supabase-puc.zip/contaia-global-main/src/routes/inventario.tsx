import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { actions, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/inventario")({
  head: () => meta("Inventario", "Módulo demostrativo de inventario por empresa."),
  component: Inventario,
});

function Inventario() {
  const { company, items, country } = useCompany();
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const [f, setF] = useState({ sku: "", name: "", qty: 0, unitCost: 0 });
  const total = items.reduce((t, i) => t + i.qty * i.unitCost, 0);
  return (
    <NeedCompany><ModuleGate module="inventario">
      <PageHeader title="Inventario" desc="Versión demostrativa, no conectada al costo de ventas."><DemoBadge /></PageHeader>
      <form className="panel mb-6 grid gap-3 p-5 sm:grid-cols-5" onSubmit={(e) => { e.preventDefault(); if (!f.name) return; actions.addItem({ ...f, companyId: company!.id, demo: true }); setF({ sku: "", name: "", qty: 0, unitCost: 0 }); }}>
        <input className="field" placeholder="SKU" value={f.sku} onChange={(e) => setF({ ...f, sku: e.target.value })} />
        <input className="field sm:col-span-2" placeholder="Producto" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input type="number" min={0} className="field" placeholder="Cantidad" value={f.qty || ""} onChange={(e) => setF({ ...f, qty: Number(e.target.value) })} />
        <input type="number" min={0} className="field" placeholder="Costo unitario" value={f.unitCost || ""} onChange={(e) => setF({ ...f, unitCost: Number(e.target.value) })} />
        <button className="btn btn-primary sm:col-span-5 sm:justify-self-start">Agregar producto</button>
      </form>
      <div className="panel overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>SKU</th><th>Producto</th><th className="text-right">Cantidad</th><th className="text-right">Costo unit.</th><th className="text-right">Valor</th></tr></thead>
          <tbody>
            {items.map((i) => <tr key={i.id}><td>{i.sku} {i.demo && <DemoBadge />}</td><td>{i.name}</td><td className="num text-right">{i.qty}</td><td className="num text-right">{fmt(i.unitCost)}</td><td className="num text-right">{fmt(i.qty * i.unitCost)}</td></tr>)}
            <tr className="font-medium"><td colSpan={4}>Valor total</td><td className="num text-right">{fmt(total)}</td></tr>
          </tbody>
        </table>
      </div>
    </ModuleGate></NeedCompany>
  );
}
