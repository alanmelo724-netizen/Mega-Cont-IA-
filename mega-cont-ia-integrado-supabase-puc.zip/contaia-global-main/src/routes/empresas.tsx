import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { DemoBadge, PageHeader } from "@/components/AppShell";
import { COUNTRIES, getCountry } from "@/lib/countries";
import { actions, useStore } from "@/lib/store";
import { meta } from "@/lib/meta";
import { L } from "@/components/Field";

export const Route = createFileRoute("/empresas")({
  head: () => meta("Empresas", "Registro de empresas con país, identificación fiscal y actividad."),
  component: Empresas,
});

const init = { name: "", country: "CO", taxId: "", activity: "", companyType: "", size: "Micro", employees: 1 };

function Empresas() {
  const { companies, activeId } = useStore();
  const [f, setF] = useState(init);
  const [demo, setDemo] = useState(false);
  const upd = (k: keyof typeof init) => (e: { target: { value: string } }) => setF({ ...f, [k]: k === "employees" ? Number(e.target.value) : e.target.value });
  const valid = f.name && f.taxId && f.activity && f.companyType;
  return (
    <>
      <PageHeader title="Empresas" desc="Cada empresa tiene sus datos contables separados." />
      <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <form className="panel grid gap-3 p-5" onSubmit={(e) => { e.preventDefault(); if (!valid) return; actions.addCompany({ ...f, demo }, demo); setF(init); setDemo(false); }}>
          <h2 className="font-semibold">Registrar empresa</h2>
          <L t="Nombre"><input className="field" value={f.name} onChange={upd("name")} required /></L>
          <L t="País"><select className="field" value={f.country} onChange={upd("country")}>{COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}</select></L>
          <L t="Identificación fiscal"><input className="field" value={f.taxId} onChange={upd("taxId")} required /></L>
          <L t="Actividad económica"><input className="field" value={f.activity} onChange={upd("activity")} required /></L>
          <div className="grid grid-cols-2 gap-3">
            <L t="Tipo de sociedad"><input className="field" placeholder="S.A.S., S.L., LLC…" value={f.companyType} onChange={upd("companyType")} required /></L>
            <L t="Tamaño"><select className="field" value={f.size} onChange={upd("size")}>{["Micro", "Pequeña", "Mediana", "Grande"].map((s) => <option key={s}>{s}</option>)}</select></L>
          </div>
          <L t="Número de empleados"><input type="number" min={0} className="field" value={f.employees} onChange={upd("employees")} /></L>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={demo} onChange={(e) => setDemo(e.target.checked)} /> Cargar transacciones ficticias de demostración</label>
          <button className="btn btn-primary" disabled={!valid}>Registrar</button>
        </form>
        <div className="grid content-start gap-3">
          {companies.map((c) => (
            <div key={c.id} className={`panel p-4 ${c.id === activeId ? "ring-2 ring-primary" : ""}`}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="font-medium">{c.name}</div>
                {c.demo && <DemoBadge />}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {getCountry(c.country).name} · NIT/ID {c.taxId} · {c.companyType} · {c.size} · {c.employees} empleados · {c.activity}
              </div>
              <div className="mt-3 flex gap-2">
                {c.id !== activeId && <button className="btn btn-outline" onClick={() => actions.setActive(c.id)}>Seleccionar</button>}
                <button className="btn btn-outline text-destructive" onClick={() => confirm("¿Eliminar empresa y todos sus datos?") && actions.deleteCompany(c.id)}>Eliminar</button>
              </div>
            </div>
          ))}
          <button className="btn btn-outline justify-self-start" onClick={() => confirm("¿Restablecer todos los datos de demostración?") && actions.resetDemo()}>Restablecer demostración</button>
        </div>
      </div>
    </>
  );
}

