import { createFileRoute } from "@tanstack/react-router";
import { NeedCompany, PageHeader } from "@/components/AppShell";
import { actions, PLANS, useCompany, type ModuleKey, type PlanId } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/plan")({
  head: () => meta("Plan y módulos", "Activa o desactiva módulos según el plan de suscripción."),
  component: Plan,
});

const NAMES: Record<ModuleKey, string> = { transacciones: "Transacciones", asientos: "Asientos contables", reportes: "Reportes", facturas: "Facturas", asistente: "Asistente IA", inventario: "Inventario", nomina: "Nómina" };

function Plan() {
  const { company, plan, modules } = useCompany();
  const allowed = PLANS[plan].modules;
  return (
    <NeedCompany>
      <PageHeader title="Plan y módulos" desc="Planes de ejemplo; no se realizan cobros." />
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        {(Object.keys(PLANS) as PlanId[]).map((p) => (
          <button key={p} onClick={() => actions.setPlan(company!.id, p)} className={`panel p-4 text-left ${p === plan ? "ring-2 ring-primary" : ""}`}>
            <div className="font-display font-semibold">{PLANS[p].name}</div>
            <div className="mt-1 text-xs text-muted-foreground">{PLANS[p].modules.length} módulos incluidos</div>
          </button>
        ))}
      </div>
      <div className="panel divide-y">
        {(Object.keys(NAMES) as ModuleKey[]).map((m) => {
          const inPlan = allowed.includes(m);
          const on = modules.includes(m);
          return (
            <label key={m} className={`flex items-center justify-between px-4 py-3 text-sm ${inPlan ? "" : "opacity-50"}`}>
              <span>{NAMES[m]} {!inPlan && <span className="text-xs text-muted-foreground">· requiere un plan superior</span>}</span>
              <input type="checkbox" className="h-4 w-4 accent-primary" disabled={!inPlan} checked={on && inPlan} onChange={() => actions.toggleModule(company!.id, m)} />
            </label>
          );
        })}
      </div>
    </NeedCompany>
  );
}
