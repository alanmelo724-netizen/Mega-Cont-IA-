import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { actions, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/facturas")({
  head: () => meta("Facturas", "Módulo demostrativo de facturación, sin validez fiscal."),
  component: Facturas,
});

function Facturas() {
  const { company, invoices, country } = useCompany();
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const [f, setF] = useState({ client: "", subtotal: 0, taxRate: 0 });
  return (
    <NeedCompany><ModuleGate module="facturas">
      <PageHeader title="Facturas" desc="Versión demostrativa: no genera facturas electrónicas ni documentos con validez fiscal."><DemoBadge /></PageHeader>
      <form className="panel mb-6 grid gap-3 p-5 sm:grid-cols-4" onSubmit={(e) => { e.preventDefault(); if (!f.client || f.subtotal <= 0) return; actions.addInvoice({ ...f, companyId: company!.id, number: `F-${String(invoices.length + 1).padStart(4, "0")}`, date: new Date().toISOString().slice(0, 10), demo: true }); setF({ client: "", subtotal: 0, taxRate: 0 }); }}>
        <input className="field sm:col-span-2" placeholder="Cliente" value={f.client} onChange={(e) => setF({ ...f, client: e.target.value })} />
        <input type="number" min={0} className="field" placeholder="Subtotal" value={f.subtotal || ""} onChange={(e) => setF({ ...f, subtotal: Number(e.target.value) })} />
        <input type="number" min={0} max={100} className="field" placeholder="Impuesto % (verificar)" value={f.taxRate || ""} onChange={(e) => setF({ ...f, taxRate: Number(e.target.value) })} />
        <button className="btn btn-primary sm:col-span-4 sm:justify-self-start">Crear factura demo</button>
      </form>
      <div className="panel overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Número</th><th>Fecha</th><th>Cliente</th><th className="text-right">Subtotal</th><th className="text-right">Impuesto</th><th className="text-right">Total</th></tr></thead>
          <tbody>{invoices.map((i) => { const tax = (i.subtotal * i.taxRate) / 100; return (
            <tr key={i.id}><td>{i.number} {i.demo && <DemoBadge />}</td><td className="num">{i.date}</td><td>{i.client}</td><td className="num text-right">{fmt(i.subtotal)}</td><td className="num text-right">{fmt(tax)} <span className="text-xs text-muted-foreground">({i.taxRate}%)</span></td><td className="num text-right">{fmt(i.subtotal + tax)}</td></tr>
          ); })}</tbody>
        </table>
      </div>
    </ModuleGate></NeedCompany>
  );
}
