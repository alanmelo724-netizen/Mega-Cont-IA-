import { createFileRoute } from "@tanstack/react-router";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { financials, money, trialBalance, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/reportes")({
  head: () => meta("Reportes", "Balance de prueba y estado de resultados de la empresa activa."),
  component: Reportes,
});

function Reportes() {
  const { lines, country, company } = useCompany();
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const tb = trialBalance(lines);
  const f = financials(lines);
  const td = tb.reduce((t, r) => t + r.debit, 0);
  const tc = tb.reduce((t, r) => t + r.credit, 0);
  const demo = lines.some((l) => l.demo);
  return (
    <NeedCompany><ModuleGate module="reportes">
      <PageHeader title="Reportes" desc={`${company?.name} · Reportes preliminares, no auditados.`}>{demo && <DemoBadge />}</PageHeader>
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="panel overflow-x-auto">
          <h2 className="border-b px-4 py-3 font-semibold">Balance de prueba</h2>
          <table className="tbl">
            <thead><tr><th>Cuenta</th><th className="text-right">Débitos</th><th className="text-right">Créditos</th><th className="text-right">Saldo</th></tr></thead>
            <tbody>
              {tb.map((r) => <tr key={r.code}><td>{r.code} {r.name}</td><td className="num text-right">{fmt(r.debit)}</td><td className="num text-right">{fmt(r.credit)}</td><td className="num text-right">{fmt(r.debit - r.credit)}</td></tr>)}
              <tr className="font-medium"><td>Totales</td><td className="num text-right">{fmt(td)}</td><td className="num text-right">{fmt(tc)}</td><td className={`text-right text-xs ${Math.abs(td - tc) < 0.005 ? "text-success" : "text-destructive"}`}>{Math.abs(td - tc) < 0.005 ? "Cuadra" : "No cuadra"}</td></tr>
            </tbody>
          </table>
        </div>
        <div className="panel">
          <h2 className="border-b px-4 py-3 font-semibold">Estado de resultados</h2>
          <table className="tbl">
            <tbody>
              {tb.filter((r) => r.type === "ingreso").map((r) => <tr key={r.code}><td>{r.name}</td><td className="num text-right">{fmt(r.credit - r.debit)}</td></tr>)}
              <tr className="font-medium"><td>Total ingresos</td><td className="num text-right">{fmt(f.ingresos)}</td></tr>
              {tb.filter((r) => r.type === "gasto").map((r) => <tr key={r.code}><td>{r.name}</td><td className="num text-right">({fmt(r.debit - r.credit)})</td></tr>)}
              <tr className="font-medium"><td>Total costos y gastos</td><td className="num text-right">({fmt(f.gastos)})</td></tr>
              <tr className="font-semibold"><td>Utilidad del periodo</td><td className={`num text-right ${f.utilidad < 0 ? "text-destructive" : "text-success"}`}>{fmt(f.utilidad)}</td></tr>
            </tbody>
          </table>
          <p className="p-4 text-xs text-muted-foreground">Antes de impuestos. No incluye cálculo tributario.</p>
        </div>
      </div>
    </ModuleGate></NeedCompany>
  );
}
