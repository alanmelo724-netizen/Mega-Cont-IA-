import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { ACCOUNTS, accountName, actions, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";
import { L } from "@/components/Field";

export const Route = createFileRoute("/transacciones")({
  head: () => meta("Transacciones", "Registro de transacciones con cuenta, débito y crédito."),
  component: Tx,
});

function Tx() {
  const { company, lines, country } = useCompany();
  const today = new Date().toISOString().slice(0, 10);
  const [f, setF] = useState({ date: today, description: "", value: 0, debit: "1110", credit: "4135" });
  const fmt = (n: number) => (n ? money(n, country.currency, country.locale) : "—");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!company || f.value <= 0 || !f.description || f.debit === f.credit) return;
    const entry = `TX-${Date.now().toString().slice(-6)}`;
    const base = { companyId: company.id, entry, date: f.date, description: f.description, demo: false };
    actions.addLines([{ ...base, account: f.debit, debit: f.value, credit: 0 }, { ...base, account: f.credit, debit: 0, credit: f.value }]);
    setF({ ...f, description: "", value: 0 });
  };
  return (
    <NeedCompany><ModuleGate module="transacciones">
      <PageHeader title="Transacciones" desc="Cada transacción genera un débito y un crédito por el mismo valor." />
      <form onSubmit={submit} className="panel mb-6 grid gap-3 p-5 md:grid-cols-6">
        <L t="Fecha"><input type="date" className="field" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></L>
        <div className="md:col-span-2"><L t="Descripción"><input className="field" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} required /></L></div>
        <L t="Valor"><input type="number" min={0} step="0.01" className="field" value={f.value || ""} onChange={(e) => setF({ ...f, value: Number(e.target.value) })} required /></L>
        <L t="Cuenta débito"><select className="field" value={f.debit} onChange={(e) => setF({ ...f, debit: e.target.value })}>{ACCOUNTS.map((a) => <option key={a.code} value={a.code}>{a.code} {a.name}</option>)}</select></L>
        <L t="Cuenta crédito"><select className="field" value={f.credit} onChange={(e) => setF({ ...f, credit: e.target.value })}>{ACCOUNTS.map((a) => <option key={a.code} value={a.code}>{a.code} {a.name}</option>)}</select></L>
        <div className="flex items-center gap-3 md:col-span-6">
          <button className="btn btn-primary" disabled={f.debit === f.credit}>Registrar transacción</button>
          {f.debit === f.credit && <span className="text-xs text-destructive">Las cuentas débito y crédito deben ser distintas.</span>}
        </div>
      </form>
      <div className="panel overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Fecha</th><th>Asiento</th><th>Descripción</th><th>Cuenta</th><th className="text-right">Débito</th><th className="text-right">Crédito</th><th></th></tr></thead>
          <tbody>
            {[...lines].reverse().map((l) => (
              <tr key={l.id}>
                <td className="num whitespace-nowrap">{l.date}</td>
                <td className="whitespace-nowrap text-xs">{l.entry} {l.demo && <DemoBadge />}</td>
                <td className="min-w-48">{l.description}</td>
                <td className="whitespace-nowrap">{accountName(l.account)}</td>
                <td className="num text-right">{fmt(l.debit)}</td>
                <td className="num text-right">{fmt(l.credit)}</td>
                <td><Link to="/asistente" search={{ tx: l.entry }} className="text-xs text-primary hover:underline">Explicar con IA</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
        {!lines.length && <p className="p-6 text-center text-sm text-muted-foreground">Aún no hay transacciones.</p>}
      </div>
    </ModuleGate></NeedCompany>
  );
}
