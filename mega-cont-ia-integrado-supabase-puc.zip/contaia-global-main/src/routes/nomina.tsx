import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { DemoBadge, ModuleGate, NeedCompany, PageHeader } from "@/components/AppShell";
import { actions, money, useCompany } from "@/lib/store";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/nomina")({
  head: () => meta("Nómina", "Módulo demostrativo de nómina, sin cálculo de aportes legales."),
  component: Nomina,
});

function Nomina() {
  const { company, employees, country } = useCompany();
  const fmt = (n: number) => money(n, country.currency, country.locale);
  const [f, setF] = useState({ name: "", role: "", salary: 0 });
  const total = employees.reduce((t, e) => t + e.salary, 0);
  return (
    <NeedCompany><ModuleGate module="nomina">
      <PageHeader title="Nómina" desc="Solo salarios base. No calcula aportes, retenciones ni prestaciones legales del país."><DemoBadge /></PageHeader>
      <form className="panel mb-6 grid gap-3 p-5 sm:grid-cols-4" onSubmit={(e) => { e.preventDefault(); if (!f.name || f.salary <= 0) return; actions.addEmployee({ ...f, companyId: company!.id, demo: true }); setF({ name: "", role: "", salary: 0 }); }}>
        <input className="field" placeholder="Nombre" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input className="field" placeholder="Cargo" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })} />
        <input type="number" min={0} className="field" placeholder="Salario mensual" value={f.salary || ""} onChange={(e) => setF({ ...f, salary: Number(e.target.value) })} />
        <button className="btn btn-primary">Agregar empleado</button>
      </form>
      <div className="panel overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Empleado</th><th>Cargo</th><th className="text-right">Salario base</th></tr></thead>
          <tbody>
            {employees.map((e) => <tr key={e.id}><td>{e.name} {e.demo && <DemoBadge />}</td><td>{e.role}</td><td className="num text-right">{fmt(e.salary)}</td></tr>)}
            <tr className="font-medium"><td colSpan={2}>Total salarios base</td><td className="num text-right">{fmt(total)}</td></tr>
          </tbody>
        </table>
      </div>
    </ModuleGate></NeedCompany>
  );
}
