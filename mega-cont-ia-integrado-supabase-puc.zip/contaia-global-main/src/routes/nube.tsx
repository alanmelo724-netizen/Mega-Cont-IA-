import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { zipSync, unzipSync, strToU8, strFromU8 } from "fflate";
import { DownloadCloud, Database, Cloud, ShieldCheck, RefreshCw } from "lucide-react";
import { PageHeader } from "@/components/AppShell";
import { getStoreSnapshot, replaceStoreSnapshot, setCloudPersistenceHandler } from "@/lib/store";
import { isSupabaseConfigured, loadCloudSnapshot, saveCloudSnapshot, supabase } from "@/lib/supabase/client";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/nube")({
  head: () => meta("Base de datos y copias de seguridad", "Conexión Supabase, sincronización y exportación de respaldo."),
  component: Nube,
});

type Notice = { kind: "success" | "error" | "info"; text: string };

function Nube() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [busy, setBusy] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [syncReady, setSyncReady] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) setUserEmail(data.session?.user.email ?? null);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserEmail(session?.user.email ?? null);
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); setCloudPersistenceHandler(null); };
  }, []);

  useEffect(() => {
    if (!supabase || !userEmail || !syncReady) { setCloudPersistenceHandler(null); return; }
    let timer: ReturnType<typeof setTimeout> | undefined;
    setCloudPersistenceHandler(snapshot => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(async () => {
        try {
          const { data } = await supabase.auth.getUser();
          if (!data.user) return;
          await saveCloudSnapshot(data.user.id, snapshot);
          setLastSync(new Date().toLocaleString("es-CO"));
        } catch (error) {
          setNotice({ kind: "error", text: `No se pudo sincronizar automáticamente: ${error instanceof Error ? error.message : "error desconocido"}` });
        }
      }, 800);
    });
    return () => { if (timer) clearTimeout(timer); setCloudPersistenceHandler(null); };
  }, [userEmail, syncReady]);

  async function signIn(signUp: boolean) {
    if (!supabase) return;
    setBusy(true); setNotice(null);
    try {
      const result = signUp
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      if (signUp && !result.data.session) {
        setNotice({ kind: "info", text: "Cuenta creada. Revisa tu correo para confirmar el registro y luego inicia sesión." });
      } else {
        setUserEmail(result.data.user?.email ?? email);
        setNotice({ kind: "success", text: signUp ? "Cuenta creada e iniciada." : "Sesión iniciada. Ahora puedes sincronizar tus datos." });
      }
    } catch (error) {
      setNotice({ kind: "error", text: error instanceof Error ? error.message : "No fue posible iniciar sesión." });
    } finally { setBusy(false); }
  }

  async function syncNow() {
    if (!supabase) return;
    setBusy(true); setNotice(null);
    try {
      const { data, error } = await supabase.auth.getUser();
      if (error) throw error;
      if (!data.user) throw new Error("Inicia sesión antes de sincronizar.");
      const cloud = await loadCloudSnapshot(data.user.id);
      if (cloud) {
        const replace = window.confirm("Ya existe una copia en la nube. ¿Quieres cargarla y reemplazar los datos locales de este navegador? Pulsa Cancelar para conservar los datos locales y guardarlos en la nube.");
        if (replace) {
          replaceStoreSnapshot(cloud as unknown as Parameters<typeof replaceStoreSnapshot>[0]);
          setNotice({ kind: "success", text: "Datos cargados desde Supabase." });
        } else {
          await saveCloudSnapshot(data.user.id, getStoreSnapshot());
          setNotice({ kind: "success", text: "Datos locales guardados en Supabase." });
        }
      } else {
        await saveCloudSnapshot(data.user.id, getStoreSnapshot());
        setNotice({ kind: "success", text: "Primera copia guardada en Supabase." });
      }
      setLastSync(new Date().toLocaleString("es-CO"));
      setSyncReady(true);
    } catch (error) {
      setNotice({ kind: "error", text: `Falló la sincronización: ${error instanceof Error ? error.message : "error desconocido"}` });
    } finally { setBusy(false); }
  }

  async function downloadBackup() {
    setBusy(true); setNotice(null);
    try {
      let cloudPayload: unknown = null;
      let cloudReadWarning: string | null = null;
      if (supabase && userEmail) {
        try {
          const { data } = await supabase.auth.getUser();
          if (data.user) cloudPayload = await loadCloudSnapshot(data.user.id);
        } catch (error) {
          cloudReadWarning = error instanceof Error ? error.message : "No fue posible leer el estado de la nube";
        }
      }
      const now = new Date();
      const snapshot = getStoreSnapshot();
      const backup = {
        product: "Mega Cont IA",
        formatVersion: 1,
        createdAt: now.toISOString(),
        source: cloudPayload ? "local-plus-cloud-check" : "local-browser",
        warning: "Respaldo de datos de la aplicación. No incluye credenciales ni archivos privados de configuración. Verifica la restauración antes de depender de esta copia.",
        localSnapshot: snapshot,
        cloudSnapshotAvailable: Boolean(cloudPayload),
        cloudReadWarning,
        cloudSnapshot: cloudPayload,
      };
      const files = {
        "respaldo-mega-cont-ia.json": strToU8(JSON.stringify(backup, null, 2)),
        "LEEME.txt": strToU8("Mega Cont IA - copia de seguridad\n\nEste ZIP contiene una exportación JSON del estado local y, si existe sesión autenticada, la copia de estado encontrada en Supabase. Guarda el archivo en un lugar seguro. Esta exportación no sustituye un backup administrado de PostgreSQL ni ha sido una prueba de restauración hasta ejecutar y verificar esa prueba.\n"),
      };
      const bytes = zipSync(files, { level: 6 });
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `mega-cont-ia-respaldo-${now.toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      setNotice({ kind: "success", text: "Archivo ZIP generado. La descarga no demuestra por sí sola que una restauración haya sido probada." });
    } catch (error) {
      setNotice({ kind: "error", text: `No se pudo crear el respaldo: ${error instanceof Error ? error.message : "error desconocido"}` });
    } finally { setBusy(false); }
  }

  async function restoreBackup(file?: File) {
    if (!file) return;
    setBusy(true); setNotice(null);
    try {
      const archive = unzipSync(new Uint8Array(await file.arrayBuffer()));
      const backupBytes = archive["respaldo-mega-cont-ia.json"];
      if (!backupBytes) throw new Error("El ZIP no contiene respaldo-mega-cont-ia.json.");
      const parsed = JSON.parse(strFromU8(backupBytes)) as { product?: string; localSnapshot?: unknown };
      if (parsed.product !== "Mega Cont IA" || !parsed.localSnapshot || typeof parsed.localSnapshot !== "object") {
        throw new Error("El archivo no parece ser una copia válida de Mega Cont IA.");
      }
      if (!window.confirm("La restauración reemplazará los datos locales de este navegador. Haz primero una copia de seguridad del estado actual. ¿Continuar?")) return;
      replaceStoreSnapshot(parsed.localSnapshot as Parameters<typeof replaceStoreSnapshot>[0]);
      setNotice({ kind: "success", text: "Copia restaurada en el navegador. Si tienes sesión en Supabase, ejecuta Sincronizar y verificar para guardar esta versión en la nube." });
    } catch (error) {
      setNotice({ kind: "error", text: `No se pudo restaurar el ZIP: ${error instanceof Error ? error.message : "archivo inválido"}` });
    } finally { setBusy(false); }
  }

  async function signOut() {
    if (!supabase) return;
    const { error } = await supabase.auth.signOut();
    if (error) setNotice({ kind: "error", text: error.message });
    else { setUserEmail(null); setSyncReady(false); setCloudPersistenceHandler(null); setNotice({ kind: "info", text: "Sesión cerrada. La aplicación conservará la copia local en este navegador." }); }
  }

  return <div className="space-y-6">
    <PageHeader title="Base de datos y copias de seguridad" desc="Conexión a Supabase, persistencia y respaldo descargable." />
    <section className="panel p-5">
      <div className="flex items-start gap-3"><Database className="mt-1 h-6 w-6" /><div className="flex-1"><h2 className="font-semibold">Estado de la conexión</h2>
        <p className="mt-1 text-sm">{isSupabaseConfigured ? "Configuración encontrada. La conexión real debe verificarse iniciando sesión y ejecutando una sincronización." : "Pendiente de configuración: agrega la URL y la clave pública de tu proyecto Supabase en el archivo .env local o en las variables de entorno del despliegue."}</p>
        <p className="mt-2 text-xs text-muted-foreground">Nunca pegues aquí la clave service_role. En el navegador solo se debe usar la clave pública anon/publishable y políticas RLS correctamente configuradas.</p>
      </div></div>
    </section>
    {isSupabaseConfigured && !userEmail && <section className="panel space-y-4 p-5">
      <h2 className="font-semibold">Acceso a la nube</h2>
      <label className="block space-y-1 text-sm">Correo electrónico<input className="field w-full" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label>
      <label className="block space-y-1 text-sm">Contraseña<input className="field w-full" type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} /></label>
      <div className="flex flex-wrap gap-2"><button className="btn btn-primary" disabled={busy || !email || password.length < 8} onClick={() => signIn(false)}>Iniciar sesión</button><button className="btn btn-secondary" disabled={busy || !email || password.length < 8} onClick={() => signIn(true)}>Crear cuenta</button></div>
      <p className="text-xs text-muted-foreground">La contraseña debe cumplir la política configurada en Supabase. Activa la confirmación de correo si deseas exigirla.</p>
    </section>}
    {isSupabaseConfigured && userEmail && <section className="panel space-y-3 p-5">
      <div className="flex items-center gap-2"><Cloud className="h-5 w-5" /><h2 className="font-semibold">Sesión conectada</h2></div>
      <p className="text-sm">Usuario: <strong>{userEmail}</strong></p>
      <p className="text-sm">Última sincronización confirmada: {lastSync ?? "todavía no verificada en esta sesión"}</p>
      <div className="flex flex-wrap gap-2"><button className="btn btn-primary" disabled={busy} onClick={syncNow}><RefreshCw className="mr-2 inline h-4 w-4" />Sincronizar y verificar</button><button className="btn btn-secondary" onClick={signOut}>Cerrar sesión</button></div>
      <p className="text-xs text-muted-foreground">Con la sesión iniciada, los cambios del estado de la aplicación se guardan automáticamente en la tabla protegida por RLS. Haz una sincronización manual al comenzar para elegir si cargas la nube o subes los datos locales.</p>
    </section>}
    <section className="panel space-y-3 p-5">
      <div className="flex items-center gap-2"><DownloadCloud className="h-5 w-5" /><h2 className="font-semibold">Copia de seguridad comprimida</h2></div>
      <p className="text-sm">Descarga un ZIP con una exportación JSON de los datos locales y, cuando exista sesión, la copia que se encuentra en la nube. No se incluyen credenciales secretas.</p>
      <div className="flex flex-wrap gap-2"><button className="btn btn-primary" disabled={busy} onClick={downloadBackup}>Descargar respaldo ZIP</button><label className="btn btn-secondary cursor-pointer">Probar restauración desde ZIP<input type="file" accept=".zip,application/zip" className="hidden" disabled={busy} onChange={e => { void restoreBackup(e.target.files?.[0]); e.currentTarget.value = ""; }} /></label></div>
    </section>
    <section className="rounded-lg border p-4 text-sm"><div className="flex gap-2"><ShieldCheck className="h-5 w-5 shrink-0" /><div><strong>Pruebas obligatorias antes de producción</strong><ul className="mt-2 list-disc space-y-1 pl-5"><li>Guardar y recuperar datos tras recargar y volver a iniciar sesión.</li><li>Comprobar RLS con dos usuarios y empresas diferentes.</li><li>Descomprimir el ZIP, revisar su contenido y probar una restauración controlada.</li><li>Configurar y comprobar también el backup nativo de PostgreSQL/Supabase.</li><li>Verificar los asientos, informes y reglas contables antes de la habilitación DIAN.</li></ul></div></div></section>
    {notice && <p role={notice.kind === "error" ? "alert" : "status"} className={`rounded border p-3 text-sm ${notice.kind === "error" ? "border-destructive" : "border-border"}`}>{notice.text}</p>}
  </div>;
}
