import { describe, expect, it } from "vitest";
import { groupEntries, financials, type Line } from "@/lib/store";
const l = (entry: string, account: string, debit: number, credit: number): Line => ({ id: Math.random().toString(), companyId: "c", entry, date: "2026-01-01", description: "x", account, debit, credit, demo: true });
describe("partida doble", () => {
  it("marca cuadrado cuando débitos = créditos", () => {
    expect(groupEntries([l("A", "1110", 100, 0), l("A", "4135", 0, 100)])[0]!.balanced).toBe(true);
  });
  it("marca descuadrado cuando difieren", () => {
    expect(groupEntries([l("A", "1110", 100, 0), l("A", "4135", 0, 90)])[0]!.balanced).toBe(false);
  });
  it("utilidad = ingresos - gastos", () => {
    const f = financials([l("A", "1110", 100, 0), l("A", "4135", 0, 100), l("B", "5120", 30, 0), l("B", "1110", 0, 30)]);
    expect(f.utilidad).toBe(70);
  });
});
