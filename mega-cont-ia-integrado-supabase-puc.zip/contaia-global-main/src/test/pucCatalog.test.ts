import { describe, expect, it } from "vitest";
import comercial from "@/data/puc/comercial.json";
import educacionSuperior from "@/data/puc/educacion-superior.json";
import financiero from "@/data/puc/financiero.json";
import { addCustomAccount, validateCatalog, validateImportRows, type PucCatalog } from "@/lib/pucCatalog";

const catalogs = [comercial, educacionSuperior, financiero] as PucCatalog[];

describe("catálogos PUC integrados", () => {
  it.each(catalogs.map(c => [c.catalogId, c] as const))("valida estructura básica del catálogo %s", (_id, catalog) => {
    const result = validateCatalog(catalog);
    expect(result.total).toBeGreaterThan(0);
    expect(result.errors).toEqual([]);
  });

  it("crea una cuenta personalizada descendiente de un padre existente", () => {
    const catalog = structuredClone(catalogs[0]);
    const parent = catalog.entries.find(entry => entry.code === "1105");
    expect(parent).toBeTruthy();
    addCustomAccount(catalog, { code: "1105001", name: "Auxiliar de prueba", parentCode: "1105" });
    expect(catalog.entries.some(entry => entry.code === "1105001" && entry.custom)).toBe(true);
  });

  it("rechaza códigos duplicados y padres que no existen en una importación", () => {
    const catalog = structuredClone(catalogs[0]);
    const result = validateImportRows([
      { codigo: "1105", nombre: "Duplicada", padre: "11" },
      { codigo: "9900001", nombre: "Sin padre", padre: "999999" },
    ], catalog);
    expect(result.accepted).toHaveLength(0);
    expect(result.errors).toHaveLength(2);
  });
});
