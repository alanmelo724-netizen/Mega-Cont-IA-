-- Mega Cont IA: estado persistente por usuario autenticado.
-- Aplicar en un proyecto Supabase de pruebas antes de conectar la aplicación.
create table if not exists public.user_app_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  constraint user_app_state_payload_is_object check (jsonb_typeof(payload) = 'object')
);

alter table public.user_app_state enable row level security;

revoke all on public.user_app_state from anon;
grant select, insert, update, delete on public.user_app_state to authenticated;

drop policy if exists "users can read their own app state" on public.user_app_state;
create policy "users can read their own app state"
  on public.user_app_state for select to authenticated
  using (user_id = auth.uid());

drop policy if exists "users can create their own app state" on public.user_app_state;
create policy "users can create their own app state"
  on public.user_app_state for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists "users can update their own app state" on public.user_app_state;
create policy "users can update their own app state"
  on public.user_app_state for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

drop policy if exists "users can delete their own app state" on public.user_app_state;
create policy "users can delete their own app state"
  on public.user_app_state for delete to authenticated
  using (user_id = auth.uid());
